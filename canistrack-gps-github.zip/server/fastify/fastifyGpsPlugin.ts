import { FastifyPluginAsync, FastifyRequest, FastifyReply } from 'fastify';

export interface CollarCommandBody {
  deviceId: string;
  command: 'beep' | 'led_toggle' | 'tracking_rate' | 'perimeter_set';
  value?: any;
}

export interface GeofencePayload {
  name: string;
  center: { lat: number; lng: number };
  radiusMeters: number;
  color?: string;
  borderStyle?: 'solid' | 'dashed';
  alertOnExit?: boolean;
  alertOnEntry?: boolean;
}

/**
 * Fastify GPS & Asset Tracking Plugin
 * Easily registers on your existing Fastify backend via:
 * fastify.register(fastifyGpsPlugin, { prefix: '/api' });
 */
export const fastifyGpsPlugin: FastifyPluginAsync = async (fastify, opts) => {
  // In-memory data store for devices (connect to PostgreSQL / MongoDB / Redis in production)
  const devices = [
    {
      id: 'entity-puppy-max',
      name: 'Max (Perrito Castaño Claro)',
      type: 'pet',
      subType: 'Golden Retriever Pup',
      tag: 'DOG-GPS-99',
      currentPosition: { lat: 19.3510, lng: -99.1620 },
      heading: 80,
      speed: 15,
      speedLimit: 30,
      battery: 92,
      status: 'moving',
      altitude: 2245,
      satellites: 16,
      accuracyMeters: 1.1,
      temperature: 24.2,
      stepsToday: 9480,
      collarSerial: 'PAWPOINT-PRO-V2',
      lastUpdated: new Date().toISOString(),
    },
    {
      id: 'entity-truck-402',
      name: 'Camión Carga Norte #402',
      type: 'truck',
      subType: 'Kenworth T680 Trailer',
      tag: 'TRUCK-CDMX-402',
      currentPosition: { lat: 19.4680, lng: -99.1390 },
      heading: 205,
      speed: 64,
      speedLimit: 80,
      battery: 98,
      status: 'moving',
      altitude: 2250,
      satellites: 14,
      accuracyMeters: 1.8,
      lastUpdated: new Date().toISOString(),
    },
  ];

  const geofences = [
    {
      id: 'geo-norte',
      name: 'Zona Norte',
      center: { lat: 19.4850, lng: -99.1280 },
      radiusMeters: 4200,
      color: '#06b6d4',
      borderStyle: 'dashed',
      active: true,
    },
    {
      id: 'geo-sur',
      name: 'Zona Sur',
      center: { lat: 19.3240, lng: -99.1860 },
      radiusMeters: 3800,
      color: '#f97316',
      borderStyle: 'dashed',
      active: true,
    },
  ];

  // 1. Health check route
  fastify.get('/health', {
    schema: {
      response: {
        200: {
          type: 'object',
          properties: {
            status: { type: 'string' },
            service: { type: 'string' },
            framework: { type: 'string' },
            timestamp: { type: 'string' },
          },
        },
      },
    },
  }, async () => {
    return {
      status: 'ok',
      service: 'CanisTrack GPS Fastify API',
      framework: 'Fastify v5',
      timestamp: new Date().toISOString(),
    };
  });

  // 2. GET /devices - List all tracked units
  fastify.get('/devices', async () => {
    return {
      total: devices.length,
      devices,
    };
  });

  // 3. GET /devices/:id - Details of specific unit
  fastify.get<{ Params: { id: string } }>('/devices/:id', {
    schema: {
      params: {
        type: 'object',
        properties: {
          id: { type: 'string' },
        },
        required: ['id'],
      },
    },
  }, async (request, reply) => {
    const device = devices.find((d) => d.id === request.params.id);
    if (!device) {
      reply.status(404).send({ error: 'Device not found' });
      return;
    }
    return device;
  });

  // 4. POST /collar/command - Remote control for GPS collar (Beep, LED, mode)
  fastify.post<{ Body: CollarCommandBody }>('/collar/command', {
    schema: {
      body: {
        type: 'object',
        properties: {
          deviceId: { type: 'string' },
          command: { type: 'string', enum: ['beep', 'led_toggle', 'tracking_rate', 'perimeter_set'] },
          value: {},
        },
        required: ['deviceId', 'command'],
      },
    },
  }, async (request, reply) => {
    const { deviceId, command, value } = request.body;
    const device = devices.find((d) => d.id === deviceId);
    if (!device) {
      reply.status(404).send({ error: 'Device not found' });
      return;
    }

    // Forward command to IoT MQTT / CoAP broker or device gateway
    fastify.log.info({ deviceId, command, value }, 'Dispatched remote command to GPS collar');

    return {
      success: true,
      deviceId,
      command,
      status: 'dispatched_to_gateway',
      timestamp: new Date().toISOString(),
    };
  });

  // 5. GET /geofences & POST /geofences
  fastify.get('/geofences', async () => {
    return {
      total: geofences.length,
      geofences,
    };
  });

  fastify.post<{ Body: GeofencePayload }>('/geofences', {
    schema: {
      body: {
        type: 'object',
        properties: {
          name: { type: 'string' },
          center: {
            type: 'object',
            properties: {
              lat: { type: 'number' },
              lng: { type: 'number' },
            },
            required: ['lat', 'lng'],
          },
          radiusMeters: { type: 'number' },
          color: { type: 'string' },
          borderStyle: { type: 'string' },
        },
        required: ['name', 'center', 'radiusMeters'],
      },
    },
  }, async (request, reply) => {
    const payload = request.body;
    const newGeofence = {
      id: `geo-${Date.now()}`,
      name: payload.name,
      center: payload.center,
      radiusMeters: payload.radiusMeters,
      color: payload.color || '#06b6d4',
      borderStyle: payload.borderStyle || 'dashed',
      active: true,
    };
    geofences.push(newGeofence);
    reply.status(201).send({ success: true, geofence: newGeofence });
  });

  // 6. SSE Stream for Live GPS Telemetry: GET /telemetry/stream
  fastify.get('/telemetry/stream', async (request, reply) => {
    reply.raw.setHeader('Content-Type', 'text/event-stream');
    reply.raw.setHeader('Cache-Control', 'no-cache');
    reply.raw.setHeader('Connection', 'keep-alive');
    reply.raw.setHeader('Access-Control-Allow-Origin', '*');

    const timer = setInterval(() => {
      const puppy = devices[0];
      const payload = JSON.stringify({
        deviceId: puppy.id,
        lat: puppy.currentPosition.lat,
        lng: puppy.currentPosition.lng,
        heading: puppy.heading,
        speed: puppy.speed,
        timestamp: new Date().toISOString(),
      });
      reply.raw.write(`data: ${payload}\n\n`);
    }, 2000);

    request.raw.on('close', () => {
      clearInterval(timer);
    });
  });
};
