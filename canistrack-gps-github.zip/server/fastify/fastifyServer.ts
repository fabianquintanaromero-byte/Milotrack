import Fastify from 'fastify';
import cors from '@fastify/cors';
import { fastifyGpsPlugin } from './fastifyGpsPlugin';

/**
 * Production-ready Fastify Server for CanisTrack GPS
 *
 * To run independently:
 * npx tsx server/fastify/fastifyServer.ts
 */
export async function createFastifyServer() {
  const fastify = Fastify({
    logger: {
      level: process.env.LOG_LEVEL || 'info',
      transport: process.env.NODE_ENV !== 'production' ? { target: 'pino-pretty' } : undefined,
    },
  });

  // CORS support for Next.js frontend
  await fastify.register(cors, {
    origin: process.env.CORS_ORIGIN || true,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    credentials: true,
  });

  // Register GPS tracking API plugin under /api
  await fastify.register(fastifyGpsPlugin, { prefix: '/api' });

  // Root landing check
  fastify.get('/', async () => {
    return {
      message: 'CanisTrack GPS Backend API is running',
      docs: '/api/health',
      frontendStack: 'Next.js (App Router / Pages Router)',
      apiStack: 'Fastify v5',
    };
  });

  return fastify;
}

// Start if executed directly
if (process.argv[1]?.includes('fastifyServer')) {
  const port = process.env.FASTIFY_PORT ? parseInt(process.env.FASTIFY_PORT, 10) : 4000;
  createFastifyServer().then((app) => {
    app.listen({ port, host: '0.0.0.0' }, (err, address) => {
      if (err) {
        app.log.error(err);
        process.exit(1);
      }
      app.log.info(`Fastify GPS API server running at ${address}`);
    });
  });
}
