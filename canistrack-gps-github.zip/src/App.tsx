import React, { useState, useEffect, useRef, useCallback } from 'react';
import { 
  TrackedEntity, 
  GeofenceZone, 
  GPSAlert, 
  MapMode, 
  GPSCoordinate 
} from './types/gps';
import { 
  INITIAL_ENTITIES, 
  INITIAL_GEOFENCES, 
  INITIAL_ALERTS, 
  PUPPY_ROUTE 
} from './data/mockGpsData';
import { GPSMap } from './components/GPSMap';
import { MapControls } from './components/MapControls';
import { NavigationHUD } from './components/NavigationHUD';
import { TelemetryHUD } from './components/TelemetryHUD';
import { Sidebar } from './components/Sidebar';
import { PuppyDetailModal } from './components/PuppyDetailModal';
import { Puppy3DMiniCam } from './components/Puppy3DMiniCam';
import { AlertsModal } from './components/AlertsModal';
import { NewGeofenceModal } from './components/NewGeofenceModal';
import { IntegrationGuideModal } from './components/IntegrationGuideModal';

// Haversine formula to compute distance in meters between two GPS coordinates
function computeDistanceMeters(p1: GPSCoordinate, p2: GPSCoordinate): number {
  const R = 6371e3; // Earth radius in meters
  const phi1 = (p1.lat * Math.PI) / 180;
  const phi2 = (p2.lat * Math.PI) / 180;
  const deltaPhi = ((p2.lat - p1.lat) * Math.PI) / 180;
  const deltaLambda = ((p2.lng - p1.lng) * Math.PI) / 180;

  const a =
    Math.sin(deltaPhi / 2) * Math.sin(deltaPhi / 2) +
    Math.cos(phi1) * Math.cos(phi2) *
    Math.sin(deltaLambda / 2) * Math.sin(deltaLambda / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

  return R * c;
}

// Compute bearing in degrees (0 - 360) from p1 to p2
function computeBearing(p1: GPSCoordinate, p2: GPSCoordinate): number {
  const y = Math.sin((p2.lng - p1.lng) * Math.PI / 180) * Math.cos(p2.lat * Math.PI / 180);
  const x =
    Math.cos(p1.lat * Math.PI / 180) * Math.sin(p2.lat * Math.PI / 180) -
    Math.sin(p1.lat * Math.PI / 180) * Math.cos(p2.lat * Math.PI / 180) * Math.cos((p2.lng - p1.lng) * Math.PI / 180);
  let brng = (Math.atan2(y, x) * 180) / Math.PI;
  return (brng + 360) % 360;
}

export default function App() {
  // Map display mode: dark, satellite, hybrid, streets
  const [mapMode, setMapMode] = useState<MapMode>('dark');
  
  // Tracked entities state
  const [entities, setEntities] = useState<TrackedEntity[]>(INITIAL_ENTITIES);
  const [selectedEntityId, setSelectedEntityId] = useState<string>('entity-puppy-max');

  // Geofences & Alerts
  const [geofences, setGeofences] = useState<GeofenceZone[]>(INITIAL_GEOFENCES);
  const [alerts, setAlerts] = useState<GPSAlert[]>(INITIAL_ALERTS);

  // Layer toggles
  const [showGeofences, setShowGeofences] = useState(true);
  const [showRoutes, setShowRoutes] = useState(true);
  const [autoCenter, setAutoCenter] = useState(true);

  // Playback / Simulation state
  const [isPlaying, setIsPlaying] = useState(true);
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1);
  const [currentRouteIndex, setCurrentRouteIndex] = useState<number>(PUPPY_ROUTE.length - 1);

  // UI Drawers & Modals
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [puppyModalOpen, setPuppyModalOpen] = useState(false);
  const [alertsModalOpen, setAlertsModalOpen] = useState(false);
  const [newGeofenceModalOpen, setNewGeofenceModalOpen] = useState(false);
  const [integrationModalOpen, setIntegrationModalOpen] = useState(false);

  // Reference to current route index for timer
  const currentRouteIndexRef = useRef(currentRouteIndex);
  currentRouteIndexRef.current = currentRouteIndex;

  const selectedEntity = entities.find((e) => e.id === selectedEntityId) || entities[0];
  const puppyEntity = entities.find((e) => e.type === 'pet') || entities[0];

  // Scrub or jump to a specific route index for the puppy
  const handleScrub = useCallback((newIndex: number) => {
    if (newIndex < 0 || newIndex >= PUPPY_ROUTE.length) return;
    setCurrentRouteIndex(newIndex);

    const nextPoint = PUPPY_ROUTE[newIndex];
    const prevPoint = newIndex > 0 ? PUPPY_ROUTE[newIndex - 1] : nextPoint;
    const newHeading = newIndex > 0 ? computeBearing(prevPoint, nextPoint) : nextPoint.heading;

    setEntities((prev) =>
      prev.map((ent) => {
        if (ent.type !== 'pet') return ent;
        return {
          ...ent,
          currentPosition: { lat: nextPoint.lat, lng: nextPoint.lng },
          heading: newHeading,
          speed: nextPoint.speed,
          altitude: 2240 + Math.round(newIndex * 1.5),
          stepsToday: 9480 + newIndex * 120,
          routeHistory: PUPPY_ROUTE.slice(0, newIndex + 1),
          lastUpdated: 'En vivo (0s)',
        };
      })
    );
  }, []);

  // Reset route to beginning
  const handleResetRoute = () => {
    handleScrub(0);
  };

  // Simulation interval: moves the puppy along the CDMX avenues!
  useEffect(() => {
    if (!isPlaying) return;

    const intervalTime = Math.max(300, 1400 / playbackSpeed);

    const timer = setInterval(() => {
      const nextIdx = (currentRouteIndexRef.current + 1) % PUPPY_ROUTE.length;
      handleScrub(nextIdx);

      // Check geofences proximity
      const currentPos = PUPPY_ROUTE[nextIdx];
      geofences.forEach((geo) => {
        if (!geo.active) return;
        const dist = computeDistanceMeters(currentPos, geo.center);
        if (dist <= geo.radiusMeters && geo.name.includes('Parque')) {
          // Inside safe perimeter
        }
      });
    }, intervalTime);

    return () => clearInterval(timer);
  }, [isPlaying, playbackSpeed, handleScrub, geofences]);

  // Center coordinate for camera
  const currentCenterCoord = selectedEntity.currentPosition;

  // Manual zoom handlers (interact with Leaflet map)
  const handleZoomIn = () => {
    window.dispatchEvent(new CustomEvent('map-zoom-in'));
  };

  const handleZoomOut = () => {
    window.dispatchEvent(new CustomEvent('map-zoom-out'));
  };

  const handleResetNorth = () => {
    // Aligns orientation to 0
    setAutoCenter(true);
  };

  const handleCenterTarget = () => {
    setAutoCenter(true);
  };

  const handleToggleGeofenceActive = (id: string) => {
    setGeofences((prev) =>
      prev.map((g) => (g.id === id ? { ...g, active: !g.active } : g))
    );
  };

  const handleAddNewGeofence = (newZone: GeofenceZone) => {
    setGeofences((prev) => [newZone, ...prev]);
  };

  const handleMarkAllAlertsAsRead = () => {
    setAlerts((prev) => prev.map((a) => ({ ...a, read: true })));
  };

  const handleCenterOnAlertCoords = (coords: GPSCoordinate) => {
    setAutoCenter(false);
    window.dispatchEvent(new CustomEvent('map-pan-to', { detail: coords }));
  };

  const unreadAlertsCount = alerts.filter((a) => !a.read).length;

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-slate-950 font-sans select-none">
      
      {/* Interactive GPS Map Viewport (Dark / Satellite / Hybrid) */}
      <GPSMap
        mapMode={mapMode}
        entities={entities}
        selectedEntityId={selectedEntityId}
        onSelectEntity={(id) => {
          setSelectedEntityId(id);
          setAutoCenter(true);
        }}
        geofences={geofences}
        showGeofences={showGeofences}
        showRoutes={showRoutes}
        centerCoordinate={currentCenterCoord}
        autoCenter={autoCenter}
        isSimulating={isPlaying}
        onOpenPuppyModal={() => setPuppyModalOpen(true)}
      />

      {/* Top Left Navigation Map Controls Cluster (Compass, Zoom, Mode Layer Switcher, Target Locator) */}
      <MapControls
        mapMode={mapMode}
        onSetMapMode={setMapMode}
        onZoomIn={handleZoomIn}
        onZoomOut={handleZoomOut}
        onResetNorth={handleResetNorth}
        onCenterTarget={handleCenterTarget}
        autoCenter={autoCenter}
        showGeofences={showGeofences}
        onToggleGeofences={() => setShowGeofences(!showGeofences)}
        showRoutes={showRoutes}
        onToggleRoutes={() => setShowRoutes(!showRoutes)}
        bearing={selectedEntity.heading}
      />

      {/* Top HUD Navigation Bar (Current Street, Waypoint, Map Mode Quick Toggle, Alerts Bell) */}
      <NavigationHUD
        currentEntity={selectedEntity}
        mapMode={mapMode}
        onSetMapMode={setMapMode}
        unreadAlertsCount={unreadAlertsCount}
        onOpenAlerts={() => setAlertsModalOpen(true)}
        onOpenPuppyModal={() => setPuppyModalOpen(true)}
        onOpenIntegrationModal={() => setIntegrationModalOpen(true)}
        isSimulating={isPlaying}
      />

      {/* Bottom Telemetry HUD & Route Playback Controls */}
      <TelemetryHUD
        currentEntity={selectedEntity}
        isPlaying={isPlaying}
        onTogglePlay={() => setIsPlaying(!isPlaying)}
        currentIndex={currentRouteIndex}
        totalPoints={PUPPY_ROUTE.length}
        onScrub={handleScrub}
        onResetRoute={handleResetRoute}
        playbackSpeed={playbackSpeed}
        onSetPlaybackSpeed={setPlaybackSpeed}
        autoCenter={autoCenter}
        onToggleAutoCenter={() => setAutoCenter(!autoCenter)}
        onOpenPuppyModal={() => setPuppyModalOpen(true)}
      />

      {/* Floating 3D Mini-Cam: Live 3D Puppy in Motion */}
      <Puppy3DMiniCam
        puppy={puppyEntity}
        isSimulating={isPlaying}
        onOpenModal={() => setPuppyModalOpen(true)}
      />

      {/* Right Drawer: Dispositivos, Perfiles, Geocercas & Telemetría */}
      <Sidebar
        entities={entities}
        selectedEntityId={selectedEntityId}
        onSelectEntity={(id) => {
          setSelectedEntityId(id);
          setAutoCenter(true);
        }}
        geofences={geofences}
        onToggleGeofenceActive={handleToggleGeofenceActive}
        onOpenNewGeofenceModal={() => setNewGeofenceModalOpen(true)}
        alerts={alerts}
        onOpenAlertsModal={() => setAlertsModalOpen(true)}
        onOpenPuppyModal={() => setPuppyModalOpen(true)}
        onOpenIntegrationModal={() => setIntegrationModalOpen(true)}
        isOpen={sidebarOpen}
        onToggleOpen={() => setSidebarOpen(!sidebarOpen)}
      />

      {/* Modal Ficha Completa del Perrito Castaño Claro (Max) */}
      <PuppyDetailModal
        puppy={puppyEntity}
        isOpen={puppyModalOpen}
        onClose={() => setPuppyModalOpen(false)}
        onCenterMap={() => {
          setSelectedEntityId(puppyEntity.id);
          setAutoCenter(true);
        }}
      />

      {/* Modal Alertas y Notificaciones del Sistema */}
      <AlertsModal
        alerts={alerts}
        isOpen={alertsModalOpen}
        onClose={() => setAlertsModalOpen(false)}
        onMarkAllAsRead={handleMarkAllAlertsAsRead}
        onCenterAlert={handleCenterOnAlertCoords}
      />

      {/* Modal Crear Nueva Geocerca */}
      <NewGeofenceModal
        isOpen={newGeofenceModalOpen}
        onClose={() => setNewGeofenceModalOpen(false)}
        onAddGeofence={handleAddNewGeofence}
        defaultCenter={selectedEntity.currentPosition}
      />

      {/* Modal Guía de Integración Fastify + Next.js */}
      <IntegrationGuideModal
        isOpen={integrationModalOpen}
        onClose={() => setIntegrationModalOpen(false)}
      />

    </div>
  );
}
