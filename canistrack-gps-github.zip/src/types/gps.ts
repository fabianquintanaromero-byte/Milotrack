export type MapMode = 'dark' | 'satellite' | 'hybrid' | 'streets';

export interface GPSCoordinate {
  lat: number;
  lng: number;
}

export interface RoutePoint {
  lat: number;
  lng: number;
  speed: number;
  heading: number;
  timestamp: string;
  altitude?: number;
  streetName?: string;
}

export type EntityType = 'pet' | 'truck' | 'van' | 'car';

export interface TrackedEntity {
  id: string;
  name: string;
  type: EntityType;
  subType: string;
  tag: string;
  avatarUrl?: string;
  color: string;
  glowColor: string;
  currentPosition: GPSCoordinate;
  heading: number; // 0 to 360 degrees
  speed: number; // km/h
  speedLimit: number;
  maxSpeedToday: number;
  avgSpeedToday: number;
  distanceTodayKm: number;
  battery: number; // 0 to 100
  batteryState: 'charging' | 'normal' | 'low';
  status: 'moving' | 'idle' | 'stopped' | 'geofence_alert' | 'offline';
  statusLabel: string;
  altitude: number; // meters above sea level
  satellites: number;
  accuracyMeters: number;
  temperature?: number; // C
  stepsToday?: number; // for pet
  currentGeofence?: string;
  routeHistory: RoutePoint[];
  lastUpdated: string;
  collarSerial?: string;
  assignedDriverOrOwner?: string;
}

export interface GeofenceZone {
  id: string;
  name: string;
  center: GPSCoordinate;
  radiusMeters: number;
  color: string;
  borderStyle: 'solid' | 'dashed';
  iconType: 'fence' | 'park' | 'warehouse' | 'home';
  active: boolean;
  alertOnExit: boolean;
  alertOnEntry: boolean;
  entityCount?: number;
}

export interface GPSAlert {
  id: string;
  entityId: string;
  entityName: string;
  type: 'geofence_exit' | 'geofence_entry' | 'speed_limit' | 'battery_low' | 'signal_lost';
  title: string;
  description: string;
  timestamp: string;
  severity: 'info' | 'warning' | 'critical';
  read: boolean;
  coordinates: GPSCoordinate;
}

export interface NavigationStep {
  instruction: string;
  distanceMeters: number;
  maneuver: 'straight' | 'turn-left' | 'turn-right' | 'u-turn' | 'arrive';
  streetName: string;
}
