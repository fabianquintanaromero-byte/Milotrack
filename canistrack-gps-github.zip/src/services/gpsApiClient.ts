import { TrackedEntity, GeofenceZone, GPSAlert } from '../types/gps';

const API_BASE_URL = typeof window !== 'undefined' && (window as any).CANISTRACK_API_URL 
  ? (window as any).CANISTRACK_API_URL 
  : '/api';

export interface HealthResponse {
  status: string;
  service: string;
  framework: string;
  uptimeSeconds?: number;
  timestamp: string;
}

export const gpsApiClient = {
  /**
   * Health Check
   */
  async getHealth(): Promise<HealthResponse> {
    const res = await fetch(`${API_BASE_URL}/health`);
    if (!res.ok) throw new Error(`HTTP Error ${res.status}`);
    return res.json();
  },

  /**
   * List all tracked units from Node.js / Fastify backend
   */
  async getDevices(): Promise<{ total: number; devices: TrackedEntity[] }> {
    const res = await fetch(`${API_BASE_URL}/devices`);
    if (!res.ok) throw new Error(`HTTP Error ${res.status}`);
    return res.json();
  },

  /**
   * Get single device info
   */
  async getDevice(id: string): Promise<TrackedEntity> {
    const res = await fetch(`${API_BASE_URL}/devices/${id}`);
    if (!res.ok) throw new Error(`HTTP Error ${res.status}`);
    return res.json();
  },

  /**
   * Send remote command to GPS collar (Beep buzzer, LED toggle, etc.)
   */
  async sendCollarCommand(deviceId: string, command: string, value?: any) {
    const res = await fetch(`${API_BASE_URL}/collar/command`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ deviceId, command, value }),
    });
    if (!res.ok) throw new Error(`HTTP Error ${res.status}`);
    return res.json();
  },

  /**
   * List all geofences
   */
  async getGeofences(): Promise<{ total: number; geofences: GeofenceZone[] }> {
    const res = await fetch(`${API_BASE_URL}/geofences`);
    if (!res.ok) throw new Error(`HTTP Error ${res.status}`);
    return res.json();
  },

  /**
   * Create a new geofence
   */
  async createGeofence(geofence: Partial<GeofenceZone>) {
    const res = await fetch(`${API_BASE_URL}/geofences`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(geofence),
    });
    if (!res.ok) throw new Error(`HTTP Error ${res.status}`);
    return res.json();
  },

  /**
   * Subscribe to live Server-Sent Events (SSE) telemetry stream
   */
  subscribeToStream(onMessage: (data: any) => void): () => void {
    if (typeof window === 'undefined' || !window.EventSource) {
      return () => {};
    }

    const eventSource = new EventSource(`${API_BASE_URL}/stream`);

    eventSource.onmessage = (event) => {
      try {
        const parsed = JSON.parse(event.data);
        onMessage(parsed);
      } catch (err) {
        // silent parse error
      }
    };

    return () => {
      eventSource.close();
    };
  },
};
