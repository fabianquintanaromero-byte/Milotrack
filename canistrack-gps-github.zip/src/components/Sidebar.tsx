import React, { useState } from 'react';
import { 
  Dog, 
  Truck, 
  Car, 
  ShieldAlert, 
  Search, 
  ChevronLeft, 
  ChevronRight, 
  Plus, 
  SlidersHorizontal, 
  Battery, 
  BatteryCharging, 
  Navigation, 
  CheckCircle2, 
  AlertTriangle,
  Radio,
  MapPin,
  Eye,
  EyeOff,
  Server
} from 'lucide-react';
import { TrackedEntity, GeofenceZone, GPSAlert } from '../types/gps';

interface SidebarProps {
  entities: TrackedEntity[];
  selectedEntityId: string;
  onSelectEntity: (id: string) => void;
  geofences: GeofenceZone[];
  onToggleGeofenceActive: (id: string) => void;
  onOpenNewGeofenceModal: () => void;
  alerts: GPSAlert[];
  onOpenAlertsModal: () => void;
  onOpenPuppyModal: () => void;
  onOpenIntegrationModal?: () => void;
  isOpen: boolean;
  onToggleOpen: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  entities,
  selectedEntityId,
  onSelectEntity,
  geofences,
  onToggleGeofenceActive,
  onOpenNewGeofenceModal,
  alerts,
  onOpenAlertsModal,
  onOpenPuppyModal,
  onOpenIntegrationModal,
  isOpen,
  onToggleOpen,
}) => {
  const [filterType, setFilterType] = useState<'all' | 'pet' | 'fleet' | 'alert'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState<'devices' | 'geofences'>('devices');

  const filteredEntities = entities.filter((entity) => {
    const matchesSearch = 
      entity.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      entity.subType.toLowerCase().includes(searchQuery.toLowerCase()) ||
      entity.tag.toLowerCase().includes(searchQuery.toLowerCase());

    if (!matchesSearch) return false;

    if (filterType === 'pet') return entity.type === 'pet';
    if (filterType === 'fleet') return entity.type !== 'pet';
    if (filterType === 'alert') return entity.status === 'geofence_alert';
    return true;
  });

  const unreadAlerts = alerts.filter(a => !a.read);

  return (
    <>
      {/* Floating Toggle Tab when Sidebar is collapsed */}
      {!isOpen && (
        <button
          onClick={onToggleOpen}
          className="absolute top-20 right-5 z-[480] bg-slate-900/95 backdrop-blur-xl border border-slate-700/80 p-2.5 rounded-2xl text-slate-300 hover:text-cyan-400 hover:bg-slate-800 transition-all shadow-2xl flex items-center gap-2"
          title="Abrir panel de dispositivos y telemetría"
        >
          <ChevronLeft className="w-5 h-5" />
          <span className="text-xs font-bold pr-1">Dispositivos ({entities.length})</span>
        </button>
      )}

      {/* Main Sidebar Drawer */}
      <aside
        className={`fixed top-0 right-0 bottom-0 z-[490] w-80 sm:w-96 bg-slate-950/95 backdrop-blur-2xl border-l border-slate-800/90 shadow-[-20px_0_50px_rgba(0,0,0,0.8)] flex flex-col transition-transform duration-300 ease-in-out ${
          isOpen ? 'translate-x-0' : 'translate-x-full'
        }`}
      >
        {/* Header */}
        <div className="p-4 border-b border-slate-800/80 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-cyan-600 to-amber-500 flex items-center justify-center text-slate-950 font-black text-sm shadow-md">
              🐕
            </div>
            <div>
              <h1 className="text-sm font-bold text-white tracking-tight flex items-center gap-1.5">
                CanisTrack GPS
              </h1>
              <p className="text-[11px] text-slate-400">
                Rastreo Satelital & Telemetría
              </p>
            </div>
          </div>

          <button
            onClick={onToggleOpen}
            className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800/80 rounded-xl transition-colors"
            title="Colapsar panel"
          >
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>

        {/* Mode / Tabs Switcher */}
        <div className="p-3 border-b border-slate-800/80">
          <div className="grid grid-cols-2 p-1 bg-slate-900 rounded-xl border border-slate-800 text-xs font-semibold">
            <button
              onClick={() => setActiveTab('devices')}
              className={`py-1.5 rounded-lg transition-all text-center ${
                activeTab === 'devices'
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Unidades ({entities.length})
            </button>
            <button
              onClick={() => setActiveTab('geofences')}
              className={`py-1.5 rounded-lg transition-all text-center ${
                activeTab === 'geofences'
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Geocercas ({geofences.length})
            </button>
          </div>
        </div>

        {/* DEVICES VIEW */}
        {activeTab === 'devices' && (
          <div className="flex-1 flex flex-col min-h-0">
            {/* Search and Filters */}
            <div className="p-3 space-y-2 border-b border-slate-800/60">
              <div className="relative">
                <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
                <input
                  type="text"
                  placeholder="Buscar perrito, camión, placa o zona..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-xl pl-9 pr-3 py-2 text-xs text-slate-200 placeholder:text-slate-500 focus:outline-none focus:border-cyan-500/50"
                />
              </div>

              {/* Segmented Filter Pills */}
              <div className="flex items-center gap-1 overflow-x-auto pb-1 text-[11px]">
                <button
                  onClick={() => setFilterType('all')}
                  className={`px-2.5 py-1 rounded-lg font-medium whitespace-nowrap transition-colors ${
                    filterType === 'all'
                      ? 'bg-slate-800 text-white'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Todos
                </button>
                <button
                  onClick={() => setFilterType('pet')}
                  className={`px-2.5 py-1 rounded-lg font-medium whitespace-nowrap transition-colors flex items-center gap-1 ${
                    filterType === 'pet'
                      ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <span>🐕</span> Mascotas
                </button>
                <button
                  onClick={() => setFilterType('fleet')}
                  className={`px-2.5 py-1 rounded-lg font-medium whitespace-nowrap transition-colors ${
                    filterType === 'fleet'
                      ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Flota
                </button>
                <button
                  onClick={() => setFilterType('alert')}
                  className={`px-2.5 py-1 rounded-lg font-medium whitespace-nowrap transition-colors flex items-center gap-1 ${
                    filterType === 'alert'
                      ? 'bg-red-500/20 text-red-300 border border-red-500/30'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <AlertTriangle className="w-3 h-3 text-red-400" />
                  Alertas
                </button>
              </div>
            </div>

            {/* List of Entities */}
            <div className="flex-1 overflow-y-auto p-3 space-y-2.5">
              {filteredEntities.map((entity) => {
                const isSelected = entity.id === selectedEntityId;
                const isPuppy = entity.type === 'pet';
                const hasAlert = entity.status === 'geofence_alert';

                return (
                  <div
                    key={entity.id}
                    onClick={() => onSelectEntity(entity.id)}
                    className={`p-3 rounded-2xl cursor-pointer transition-all border text-left relative overflow-hidden ${
                      isSelected
                        ? isPuppy
                          ? 'bg-amber-950/20 border-amber-500/60 shadow-[0_4px_20px_rgba(245,158,11,0.15)] ring-1 ring-amber-500/30'
                          : 'bg-cyan-950/20 border-cyan-500/60 shadow-[0_4px_20px_rgba(6,182,212,0.15)] ring-1 ring-cyan-500/30'
                        : 'bg-slate-900/60 border-slate-800/80 hover:bg-slate-900 hover:border-slate-700'
                    }`}
                  >
                    {/* Header Row */}
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center gap-2.5 min-w-0">
                        {/* Avatar / Icon */}
                        {isPuppy && entity.avatarUrl ? (
                          <div className="relative w-10 h-10 rounded-xl overflow-hidden border-2 border-amber-500/60 shrink-0 shadow-md">
                            <img
                              src={entity.avatarUrl}
                              alt={entity.name}
                              className="w-full h-full object-cover"
                              referrerPolicy="no-referrer"
                            />
                            <div className="absolute bottom-0 right-0 w-3 h-3 rounded-full bg-emerald-500 border border-slate-900" />
                          </div>
                        ) : (
                          <div
                            className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0 border"
                            style={{
                              backgroundColor: `${entity.color}20`,
                              borderColor: `${entity.color}60`,
                              color: entity.color,
                            }}
                          >
                            {entity.type === 'truck' ? (
                              <Truck className="w-5 h-5" />
                            ) : (
                              <Car className="w-5 h-5" />
                            )}
                          </div>
                        )}

                        <div className="min-w-0">
                          <div className="flex items-center gap-1.5">
                            <h3 className="text-xs font-bold text-white truncate">
                              {entity.name}
                            </h3>
                          </div>
                          <p className="text-[11px] text-slate-400 truncate">
                            {entity.subType}
                          </p>
                        </div>
                      </div>

                      {/* Speed Badge */}
                      <div className="text-right shrink-0">
                        <span
                          className={`font-mono-nums text-xs font-bold px-2 py-0.5 rounded-lg border ${
                            hasAlert
                              ? 'bg-red-500/20 text-red-300 border-red-500/40'
                              : 'bg-slate-800 text-slate-200 border-slate-700'
                          }`}
                        >
                          {entity.speed} km/h
                        </span>
                      </div>
                    </div>

                    {/* Status & Location description */}
                    <div className="mt-2.5 pt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
                      <div className="flex items-center gap-1.5 truncate">
                        <Radio className="w-3 h-3 text-cyan-400 animate-pulse shrink-0" />
                        <span className="truncate">{entity.statusLabel}</span>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        <span className="flex items-center gap-1 font-mono-nums">
                          <Battery className="w-3 h-3 text-emerald-400" />
                          {entity.battery}%
                        </span>
                      </div>
                    </div>

                    {/* Specific Perrito Action Button */}
                    {isPuppy && (
                      <div className="mt-2.5 flex items-center gap-2">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            onOpenPuppyModal();
                          }}
                          className="w-full py-1.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/40 text-amber-300 text-xs font-bold flex items-center justify-center gap-1.5 transition-colors shadow-sm"
                        >
                          <span>🐕</span> Ver Perrito Caminando en 3D
                        </button>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* GEOFENCES VIEW */}
        {activeTab === 'geofences' && (
          <div className="flex-1 flex flex-col min-h-0">
            <div className="p-3 flex items-center justify-between border-b border-slate-800/60">
              <span className="text-xs font-semibold text-slate-300">
                Polígonos Activos ({geofences.filter(g => g.active).length})
              </span>
              <button
                onClick={onOpenNewGeofenceModal}
                className="px-2.5 py-1 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-lg text-xs flex items-center gap-1 transition-colors"
              >
                <Plus className="w-3.5 h-3.5" />
                Nueva Geocerca
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-3 space-y-2">
              {geofences.map((geo) => (
                <div
                  key={geo.id}
                  className="p-3 bg-slate-900/60 border border-slate-800 rounded-xl flex items-center justify-between gap-3 text-left"
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div
                      className="w-3.5 h-3.5 rounded-full shrink-0 border"
                      style={{
                        backgroundColor: geo.color,
                        borderColor: '#ffffff',
                      }}
                    />
                    <div className="min-w-0">
                      <h4 className="text-xs font-bold text-white truncate">
                        {geo.name}
                      </h4>
                      <p className="text-[11px] text-slate-400 font-mono-nums">
                        Radio: {(geo.radiusMeters / 1000).toFixed(1)} km · {geo.borderStyle === 'dashed' ? 'Límite punteado' : 'Límite sólido'}
                      </p>
                    </div>
                  </div>

                  <button
                    onClick={() => onToggleGeofenceActive(geo.id)}
                    className={`p-1.5 rounded-lg border transition-colors ${
                      geo.active
                        ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                        : 'bg-slate-800 text-slate-500 border-slate-700'
                    }`}
                    title={geo.active ? 'Desactivar geocerca' : 'Activar geocerca'}
                  >
                    {geo.active ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Next.js & Fastify Integration Banner */}
        {onOpenIntegrationModal && (
          <div className="p-3 border-t border-slate-800/80 bg-slate-950/60">
            <button
              onClick={onOpenIntegrationModal}
              className="w-full py-2 px-3 rounded-xl bg-cyan-950/60 hover:bg-cyan-900/60 border border-cyan-500/40 text-cyan-300 text-xs font-bold flex items-center justify-between transition-colors shadow-sm"
            >
              <div className="flex items-center gap-2">
                <Server className="w-4 h-4 text-cyan-400" />
                <span>Next.js + Fastify API</span>
              </div>
              <span className="text-[10px] bg-cyan-500/20 px-2 py-0.5 rounded text-cyan-300 font-mono">
                Ver Guía
              </span>
            </button>
          </div>
        )}

        {/* Footer Summary Strip */}
        <div className="p-3 border-t border-slate-800/80 bg-slate-900/80 flex items-center justify-between text-xs">
          <div className="flex items-center gap-1.5 text-slate-400">
            <span className="w-2 h-2 rounded-full bg-emerald-400" />
            <span>Servidor GPS Operativo</span>
          </div>

          <button
            onClick={onOpenAlertsModal}
            className="flex items-center gap-1.5 text-cyan-400 hover:text-cyan-300 font-medium"
          >
            <span>Ver Alertas ({unreadAlerts.length})</span>
          </button>
        </div>
      </aside>
    </>
  );
};
