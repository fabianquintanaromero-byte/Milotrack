import React, { useEffect, useRef } from 'react';
import L from 'leaflet';
import { TrackedEntity, GeofenceZone, MapMode, GPSCoordinate } from '../types/gps';
import { createPuppyMarkerHtml, createVehicleMarkerHtml } from '../utils/markerUtils';

interface GPSMapProps {
  mapMode: MapMode;
  entities: TrackedEntity[];
  selectedEntityId: string;
  onSelectEntity: (id: string) => void;
  geofences: GeofenceZone[];
  showGeofences: boolean;
  showRoutes: boolean;
  centerCoordinate?: GPSCoordinate;
  autoCenter: boolean;
  isSimulating: boolean;
  onOpenPuppyModal: () => void;
}

export const GPSMap: React.FC<GPSMapProps> = ({
  mapMode,
  entities,
  selectedEntityId,
  onSelectEntity,
  geofences,
  showGeofences,
  showRoutes,
  centerCoordinate,
  autoCenter,
  isSimulating,
  onOpenPuppyModal,
}) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const tileLayerRef = useRef<L.TileLayer | null>(null);
  const labelLayerRef = useRef<L.TileLayer | null>(null);
  const markersRef = useRef<{ [key: string]: L.Marker }>({});
  const polylinesRef = useRef<L.Polyline[]>([]);
  const circlesRef = useRef<L.Circle[]>([]);

  // Initialize Leaflet Map
  useEffect(() => {
    if (!mapContainerRef.current || mapInstanceRef.current) return;

    // Default center Ciudad de México (matching user's screenshot)
    const map = L.map(mapContainerRef.current, {
      center: [19.3850, -99.1680],
      zoom: 12,
      zoomControl: false, // We provide modern styled controls
      attributionControl: false,
    });

    // Add scale bar matching the "5 km" in the user screenshot
    L.control.scale({
      position: 'bottomleft',
      metric: true,
      imperial: false,
      maxWidth: 120,
    }).addTo(map);

    const handleZoomInEvent = () => map.zoomIn();
    const handleZoomOutEvent = () => map.zoomOut();
    const handlePanToEvent = (e: any) => {
      if (e.detail?.lat && e.detail?.lng) {
        map.setView([e.detail.lat, e.detail.lng], 14, { animate: true });
      }
    };

    window.addEventListener('map-zoom-in', handleZoomInEvent);
    window.addEventListener('map-zoom-out', handleZoomOutEvent);
    window.addEventListener('map-pan-to', handlePanToEvent);

    mapInstanceRef.current = map;

    return () => {
      window.removeEventListener('map-zoom-in', handleZoomInEvent);
      window.removeEventListener('map-zoom-out', handleZoomOutEvent);
      window.removeEventListener('map-pan-to', handlePanToEvent);
      map.remove();
      mapInstanceRef.current = null;
    };
  }, []);

  // Update Tile Layer based on mapMode (dark vs satellite vs hybrid vs streets)
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    // Remove existing tile layers
    if (tileLayerRef.current) {
      map.removeLayer(tileLayerRef.current);
      tileLayerRef.current = null;
    }
    if (labelLayerRef.current) {
      map.removeLayer(labelLayerRef.current);
      labelLayerRef.current = null;
    }

    if (mapMode === 'dark') {
      // CartoDB Dark Matter (matching image 2)
      tileLayerRef.current = L.tileLayer(
        'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png',
        {
          subdomains: 'abcd',
          maxZoom: 20,
        }
      ).addTo(map);
    } else if (mapMode === 'satellite') {
      // Esri World Imagery (matching image 1)
      tileLayerRef.current = L.tileLayer(
        'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
        {
          maxZoom: 19,
        }
      ).addTo(map);
    } else if (mapMode === 'hybrid') {
      // Esri Satellite + Street & Boundary Labels
      tileLayerRef.current = L.tileLayer(
        'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
        {
          maxZoom: 19,
        }
      ).addTo(map);

      labelLayerRef.current = L.tileLayer(
        'https://server.arcgisonline.com/ArcGIS/rest/services/Reference/World_Boundaries_and_Places/MapServer/tile/{z}/{y}/{x}',
        {
          maxZoom: 19,
        }
      ).addTo(map);
    } else {
      // Standard Streets / Navigation
      tileLayerRef.current = L.tileLayer(
        'https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png',
        {
          subdomains: 'abcd',
          maxZoom: 19,
        }
      ).addTo(map);
    }
  }, [mapMode]);

  // Render Geofences (Zonas)
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    // Clear old circles
    circlesRef.current.forEach((c) => map.removeLayer(c));
    circlesRef.current = [];

    if (!showGeofences) return;

    geofences.forEach((geo) => {
      if (!geo.active) return;

      const circle = L.circle([geo.center.lat, geo.center.lng], {
        radius: geo.radiusMeters,
        color: geo.color,
        weight: geo.borderStyle === 'dashed' ? 2 : 2.5,
        dashArray: geo.borderStyle === 'dashed' ? '6, 8' : undefined,
        fillColor: geo.color,
        fillOpacity: mapMode === 'satellite' ? 0.22 : 0.14,
      }).addTo(map);

      // Label at the center of the geofence matching image 1 and 2
      const labelIcon = L.divIcon({
        className: 'geofence-label-marker',
        html: `
          <div style="
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            background: rgba(15, 23, 42, 0.75);
            backdrop-filter: blur(6px);
            border: 1px solid ${geo.color};
            border-radius: 8px;
            padding: 4px 10px;
            color: #ffffff;
            font-size: 11px;
            font-weight: 700;
            letter-spacing: 0.05em;
            text-transform: uppercase;
            box-shadow: 0 4px 12px rgba(0,0,0,0.5);
            white-space: nowrap;
            pointer-events: none;
            transform: translate(-50%, -50%);
          ">
            <span style="font-size: 13px; margin-bottom: 2px;">${geo.iconType === 'park' ? '🌳' : '⛩️'}</span>
            <span style="color: ${geo.color};">${geo.name}</span>
            <span style="font-size: 9px; color: #94a3b8; font-family: monospace;">R: ${(geo.radiusMeters / 1000).toFixed(1)} km</span>
          </div>
        `,
        iconSize: [0, 0],
      });

      const labelMarker = L.marker([geo.center.lat, geo.center.lng], {
        icon: labelIcon,
        interactive: false,
      }).addTo(map);

      // Add to cleanup
      circlesRef.current.push(circle as any);
      circlesRef.current.push(labelMarker as any);
    });
  }, [geofences, showGeofences, mapMode]);

  // Render Routes (Polylines)
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    polylinesRef.current.forEach((p) => map.removeLayer(p));
    polylinesRef.current = [];

    if (!showRoutes) return;

    entities.forEach((entity) => {
      if (!entity.routeHistory || entity.routeHistory.length < 2) return;

      const latlngs: [number, number][] = entity.routeHistory.map((pt) => [pt.lat, pt.lng]);

      // Outer glow line
      const glowPoly = L.polyline(latlngs, {
        color: entity.glowColor,
        weight: entity.type === 'pet' ? 6 : 5,
        opacity: 0.45,
        lineCap: 'round',
        lineJoin: 'round',
      }).addTo(map);

      // Inner crisp neon line
      const mainPoly = L.polyline(latlngs, {
        color: entity.type === 'pet' ? '#38bdf8' : entity.color,
        weight: entity.type === 'pet' ? 3.5 : 3,
        opacity: 0.95,
        lineCap: 'round',
        lineJoin: 'round',
      }).addTo(map);

      polylinesRef.current.push(glowPoly, mainPoly);
    });
  }, [entities, showRoutes]);

  // Update Markers (including the light-brown puppy marker!)
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    entities.forEach((entity) => {
      const isSelected = entity.id === selectedEntityId;
      const pos: [number, number] = [entity.currentPosition.lat, entity.currentPosition.lng];

      let icon: L.DivIcon;

      if (entity.type === 'pet') {
        // High fidelity light-brown puppy marker with directional heading cone!
        icon = L.divIcon({
          className: 'custom-puppy-icon',
          html: createPuppyMarkerHtml(
            entity.heading,
            entity.speed,
            entity.name.split(' ')[0], // "Max"
            isSelected,
            isSimulating || entity.status === 'moving'
          ),
          iconSize: [64, 64],
          iconAnchor: [32, 32],
        });
      } else {
        // Fleet vehicle markers matching image 1 and image 2
        const hasAlert = entity.status === 'geofence_alert';
        icon = L.divIcon({
          className: 'custom-vehicle-icon',
          html: createVehicleMarkerHtml(
            entity.type,
            entity.color,
            entity.speed,
            entity.heading,
            hasAlert
          ),
          iconSize: [44, 50],
          iconAnchor: [22, 48],
        });
      }

      if (markersRef.current[entity.id]) {
        // Update existing marker position & icon
        markersRef.current[entity.id].setLatLng(pos);
        markersRef.current[entity.id].setIcon(icon);
      } else {
        // Create new marker
        const marker = L.marker(pos, { icon }).addTo(map);
        marker.on('click', () => {
          onSelectEntity(entity.id);
          if (entity.type === 'pet') {
            onOpenPuppyModal();
          }
        });
        markersRef.current[entity.id] = marker;
      }
    });

    // Cleanup markers that are no longer in entities
    Object.keys(markersRef.current).forEach((id) => {
      if (!entities.some((e) => e.id === id)) {
        map.removeLayer(markersRef.current[id]);
        delete markersRef.current[id];
      }
    });
  }, [entities, selectedEntityId, isSimulating, onSelectEntity, onOpenPuppyModal]);

  // Camera pan on autoCenter or centerCoordinate change
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map || !autoCenter) return;

    if (centerCoordinate) {
      map.panTo([centerCoordinate.lat, centerCoordinate.lng], {
        animate: true,
        duration: 0.5,
      });
    }
  }, [centerCoordinate, autoCenter]);

  return (
    <div className="relative w-full h-full select-none">
      {/* Leaflet container */}
      <div ref={mapContainerRef} className="w-full h-full z-0" />
    </div>
  );
};
