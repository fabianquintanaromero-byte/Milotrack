import React, { useState } from 'react';
import { Puppy3DViewer } from './Puppy3DViewer';
import { TrackedEntity } from '../types/gps';
import { Eye, EyeOff, Maximize2, Radio, Compass, ChevronDown, ChevronUp } from 'lucide-react';

interface Puppy3DMiniCamProps {
  puppy: TrackedEntity;
  isSimulating: boolean;
  onOpenModal: () => void;
}

export const Puppy3DMiniCam: React.FC<Puppy3DMiniCamProps> = ({
  puppy,
  isSimulating,
  onOpenModal,
}) => {
  const [minimized, setMinimized] = useState(false);
  const [closed, setClosed] = useState(false);

  if (closed) {
    return (
      <button
        onClick={() => setClosed(false)}
        className="absolute bottom-36 left-5 z-[460] bg-slate-900/95 backdrop-blur-xl border border-amber-500/40 px-3 py-2 rounded-2xl text-amber-300 hover:bg-slate-800 transition-all shadow-2xl flex items-center gap-2 text-xs font-bold"
        title="Abrir cámara 3D en vivo de Max"
      >
        <span>🐕</span>
        <span>Cámara 3D de Max</span>
      </button>
    );
  }

  return (
    <div className="absolute bottom-36 left-5 z-[460] w-64 sm:w-72 bg-slate-950/90 backdrop-blur-2xl border border-amber-500/40 rounded-2xl shadow-2xl overflow-hidden flex flex-col pointer-events-auto animate-in fade-in slide-in-from-bottom-4 duration-200">
      {/* Mini-Cam Header */}
      <div className="px-3 py-2 bg-slate-900/90 border-b border-slate-800 flex items-center justify-between">
        <div className="flex items-center gap-2 min-w-0">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse shrink-0" />
          <span className="text-xs font-bold text-white truncate flex items-center gap-1.5">
            <span>🐕</span> Max 3D en Vivo
          </span>
          <span className="text-[10px] text-amber-400 font-mono-nums font-semibold shrink-0">
            {puppy.speed} km/h
          </span>
        </div>

        <div className="flex items-center gap-1 shrink-0">
          <button
            onClick={() => setMinimized(!minimized)}
            className="p-1 text-slate-400 hover:text-white rounded-lg transition-colors"
            title={minimized ? 'Expandir cámara 3D' : 'Minimizar cámara 3D'}
          >
            {minimized ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
          </button>

          <button
            onClick={onOpenModal}
            className="p-1 text-slate-400 hover:text-amber-400 rounded-lg transition-colors"
            title="Abrir visor 3D en pantalla completa"
          >
            <Maximize2 className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={() => setClosed(true)}
            className="p-1 text-slate-500 hover:text-slate-300 rounded-lg transition-colors text-xs"
            title="Ocultar cámara 3D"
          >
            ✕
          </button>
        </div>
      </div>

      {/* 3D Viewport when not minimized */}
      {!minimized && (
        <div className="relative bg-slate-950">
          <Puppy3DViewer
            speed={puppy.speed}
            isMoving={isSimulating || puppy.status === 'moving'}
            collarLedActive={true}
            interactive={true}
            heightClass="h-40 sm:h-44"
            showControls={false}
          />

          {/* Compass & Street Sub-overlay */}
          <div className="absolute bottom-2 left-2 right-2 flex items-center justify-between text-[10px] font-mono-nums text-slate-300 bg-slate-950/80 backdrop-blur-md px-2 py-1 rounded-lg border border-slate-800 pointer-events-none">
            <span className="flex items-center gap-1 text-cyan-400 font-bold">
              <Compass className="w-3 h-3" />
              {Math.round(puppy.heading)}°
            </span>
            <span className="truncate max-w-[150px] text-slate-400">
              {puppy.routeHistory?.[puppy.routeHistory.length - 1]?.streetName || 'Coyoacán, CDMX'}
            </span>
          </div>
        </div>
      )}
    </div>
  );
};
