import React from 'react';
import { 
  Navigation, 
  MapPin, 
  Moon, 
  Globe, 
  Sparkles, 
  Bell, 
  Dog, 
  ShieldCheck, 
  ChevronRight,
  Radio,
  Server,
  Download
} from 'lucide-react';
import { TrackedEntity, MapMode } from '../types/gps';

interface NavigationHUDProps {
  currentEntity: TrackedEntity;
  mapMode: MapMode;
  onSetMapMode: (mode: MapMode) => void;
  unreadAlertsCount: number;
  onOpenAlerts: () => void;
  onOpenPuppyModal: () => void;
  onOpenIntegrationModal?: () => void;
  isSimulating: boolean;
}

export const NavigationHUD: React.FC<NavigationHUDProps> = ({
  currentEntity,
  mapMode,
  onSetMapMode,
  unreadAlertsCount,
  onOpenAlerts,
  onOpenPuppyModal,
  onOpenIntegrationModal,
  isSimulating,
}) => {
  const isPuppy = currentEntity.type === 'pet';

  return (
    <div className="absolute top-5 left-20 right-5 z-[450] flex items-center justify-between pointer-events-none gap-4">
      {/* Navigation Banner on the center/left */}
      <div className="pointer-events-auto flex items-center gap-3 bg-slate-900/90 backdrop-blur-xl border border-slate-700/80 rounded-2xl px-4 py-2.5 shadow-2xl max-w-2xl">
        
        {/* Navigation Icon / Entity Badge */}
        <div 
          onClick={isPuppy ? onOpenPuppyModal : undefined}
          className={`flex items-center justify-center w-10 h-10 rounded-xl cursor-pointer transition-transform hover:scale-105 shrink-0 ${
            isPuppy 
              ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40 shadow-[0_0_15px_rgba(245,158,11,0.25)]' 
              : 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/40 shadow-[0_0_15px_rgba(6,182,212,0.25)]'
          }`}
          title={isPuppy ? "Ver ficha de Max (Perrito Castaño)" : currentEntity.name}
        >
          {isPuppy ? (
            <Dog className="w-5 h-5 text-amber-400" />
          ) : (
            <Navigation className="w-5 h-5" style={{ transform: `rotate(${currentEntity.heading}deg)` }} />
          )}
        </div>

        {/* Current Street & Waypoint Info */}
        <div className="flex flex-col min-w-0 pr-2">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-white truncate flex items-center gap-1.5">
              {currentEntity.name}
            </span>
            <span className="text-[10px] text-slate-400 font-mono-nums">
              · {currentEntity.speed} km/h
            </span>
            {isSimulating && (
              <span className="inline-flex items-center gap-1 text-[10px] text-cyan-400 font-semibold bg-cyan-950/60 px-1.5 py-0.5 rounded border border-cyan-800/60">
                <Radio className="w-2.5 h-2.5 animate-pulse" /> En Vivo
              </span>
            )}
          </div>

          <div className="flex items-center gap-1.5 text-xs text-slate-300 mt-0.5 truncate">
            <MapPin className="w-3.5 h-3.5 text-amber-400 shrink-0" />
            <span className="truncate font-medium text-slate-200">
              {currentEntity.routeHistory?.[currentEntity.routeHistory.length - 1]?.streetName || 'Ciudad de México, CDMX'}
            </span>
            <ChevronRight className="w-3 h-3 text-slate-500 shrink-0" />
            <span className="text-[11px] text-slate-400 hidden sm:inline">
              Rumbo {Math.round(currentEntity.heading)}°
            </span>
          </div>
        </div>

        {/* Status Chip */}
        <div className="hidden lg:flex items-center gap-1.5 pl-3 border-l border-slate-800 text-[11px] text-emerald-400 whitespace-nowrap">
          <ShieldCheck className="w-3.5 h-3.5" />
          <span>{currentEntity.currentGeofence || 'GPS 3D Bloqueado'}</span>
        </div>
      </div>

      {/* Right Action Bar: Quick Mode Toggle & Alerts */}
      <div className="pointer-events-auto flex items-center gap-2.5 shrink-0">
        
        {/* Quick Map Mode Switcher Buttons */}
        <div className="bg-slate-900/90 backdrop-blur-xl border border-slate-700/80 rounded-2xl p-1 shadow-2xl flex items-center gap-1">
          <button
            onClick={() => onSetMapMode('dark')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
              mapMode === 'dark'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/70'
            }`}
            title="Modo Oscuro (Vector nocturno)"
          >
            <Moon className="w-3.5 h-3.5" />
            <span className="hidden md:inline">Oscuro</span>
          </button>

          <button
            onClick={() => onSetMapMode('satellite')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
              mapMode === 'satellite'
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 shadow-sm'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/70'
            }`}
            title="Modo Satélite (Fotografía aérea de alta resolución)"
          >
            <Globe className="w-3.5 h-3.5" />
            <span className="hidden md:inline">Satélite</span>
          </button>

          <button
            onClick={() => onSetMapMode('hybrid')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
              mapMode === 'hybrid'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-sm'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/70'
            }`}
            title="Modo Híbrido (Satélite con etiquetas de calles)"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span className="hidden md:inline">Híbrido</span>
          </button>
        </div>

        {/* Next.js & Fastify Integration Guide Button */}
        {onOpenIntegrationModal && (
          <button
            onClick={onOpenIntegrationModal}
            className="flex items-center gap-1.5 px-3 py-2 rounded-2xl bg-cyan-950/70 border border-cyan-500/40 text-cyan-300 hover:bg-cyan-900/80 transition-all text-xs font-bold shadow-lg"
            title="Integración en plataforma propia (Next.js + Fastify API)"
          >
            <Server className="w-3.5 h-3.5 text-cyan-400" />
            <span className="hidden xl:inline">Next.js + Fastify</span>
          </button>
        )}

        {/* Download ZIP for GitHub direct link */}
        <a
          href="/api/download-zip"
          download="canistrack-gps-github.zip"
          className="flex items-center gap-1.5 px-3 py-2 rounded-2xl bg-emerald-950/70 border border-emerald-500/40 text-emerald-300 hover:bg-emerald-900/80 transition-all text-xs font-bold shadow-lg"
          title="Descargar paquete ZIP completo del proyecto para subir a GitHub"
        >
          <Download className="w-3.5 h-3.5 text-emerald-400" />
          <span className="hidden sm:inline">Descargar ZIP</span>
        </a>

        {/* Alerts Trigger Button */}
        <button
          onClick={onOpenAlerts}
          className="relative flex items-center justify-center w-10 h-10 rounded-2xl bg-slate-900/90 backdrop-blur-xl border border-slate-700/80 text-slate-300 hover:text-white hover:bg-slate-800/80 transition-all shadow-2xl"
          title="Notificaciones y Alertas de Geocercas"
        >
          <Bell className="w-4 h-4" />
          {unreadAlertsCount > 0 && (
            <span className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-red-500 text-white text-[10px] font-bold flex items-center justify-center border-2 border-slate-900 animate-pulse">
              {unreadAlertsCount}
            </span>
          )}
        </button>

        {/* Perrito Details Quick Button */}
        {isPuppy && (
          <button
            onClick={onOpenPuppyModal}
            className="flex items-center gap-2 px-3 py-2 rounded-2xl bg-amber-500/20 border border-amber-500/40 text-amber-300 hover:bg-amber-500/30 transition-all shadow-[0_0_20px_rgba(245,158,11,0.2)] text-xs font-bold"
          >
            <span>🐕</span>
            <span className="hidden sm:inline">Max 3D en Vivo</span>
          </button>
        )}
      </div>
    </div>
  );
};
