import React from 'react';
import { 
  Play, 
  Pause, 
  SkipBack, 
  SkipForward, 
  Battery, 
  BatteryCharging, 
  Gauge, 
  Footprints, 
  Thermometer, 
  Compass, 
  Mountain, 
  Crosshair,
  RotateCcw
} from 'lucide-react';
import { TrackedEntity } from '../types/gps';

interface TelemetryHUDProps {
  currentEntity: TrackedEntity;
  isPlaying: boolean;
  onTogglePlay: () => void;
  currentIndex: number;
  totalPoints: number;
  onScrub: (index: number) => void;
  onResetRoute: () => void;
  playbackSpeed: number;
  onSetPlaybackSpeed: (speed: number) => void;
  autoCenter: boolean;
  onToggleAutoCenter: () => void;
  onOpenPuppyModal: () => void;
}

export const TelemetryHUD: React.FC<TelemetryHUDProps> = ({
  currentEntity,
  isPlaying,
  onTogglePlay,
  currentIndex,
  totalPoints,
  onScrub,
  onResetRoute,
  playbackSpeed,
  onSetPlaybackSpeed,
  autoCenter,
  onToggleAutoCenter,
  onOpenPuppyModal,
}) => {
  const isPuppy = currentEntity.type === 'pet';
  const currentPoint = currentEntity.routeHistory[currentIndex] || currentEntity.routeHistory[0];

  // Helper for cardinal direction
  const getCardinal = (heading: number) => {
    const directions = ['N', 'NE', 'E', 'SE', 'S', 'SO', 'O', 'NO'];
    const index = Math.round(((heading % 360) / 45)) % 8;
    return directions[index];
  };

  const speedPercentage = Math.min(100, (currentEntity.speed / (currentEntity.speedLimit || 80)) * 100);

  return (
    <div className="absolute bottom-5 left-5 right-5 z-[450] flex flex-col gap-2.5 max-w-5xl mx-auto pointer-events-none">
      
      {/* Upper Metrics Strip + Mini Speedometer */}
      <div className="pointer-events-auto bg-slate-900/90 backdrop-blur-xl border border-slate-700/80 rounded-2xl p-3 shadow-2xl flex flex-wrap items-center justify-between gap-3">
        
        {/* Speedometer Cluster */}
        <div className="flex items-center gap-3.5 pl-1">
          <div className="relative flex items-center justify-center w-14 h-14 rounded-full bg-slate-950/80 border border-slate-700 shadow-inner">
            {/* SVG Circular Speed Arc */}
            <svg className="w-14 h-14 -rotate-90 transform" viewBox="0 0 36 36">
              <path
                className="text-slate-800"
                strokeWidth="3.5"
                stroke="currentColor"
                fill="none"
                d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
              />
              <path
                className={isPuppy ? 'text-amber-500' : 'text-cyan-400'}
                strokeDasharray={`${speedPercentage}, 100`}
                strokeWidth="3.5"
                strokeLinecap="round"
                stroke="currentColor"
                fill="none"
                d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
              />
            </svg>
            <div className="absolute flex flex-col items-center">
              <span className="text-base font-extrabold text-white font-mono-nums leading-none">
                {currentEntity.speed}
              </span>
              <span className="text-[8px] font-semibold text-slate-400 uppercase tracking-tighter">
                km/h
              </span>
            </div>
          </div>

          <div className="flex flex-col">
            <div className="flex items-center gap-1.5">
              <span className="text-sm font-bold text-white tracking-tight">
                {isPuppy ? '🐕 Ritmo de Max' : currentEntity.name}
              </span>
              {currentEntity.speed > currentEntity.speedLimit && (
                <span className="text-[10px] text-red-400 font-bold bg-red-950/80 px-1.5 py-0.5 rounded border border-red-800 animate-pulse">
                  Exceso
                </span>
              )}
            </div>
            <span className="text-[11px] text-slate-400 font-mono-nums">
              Límite: {currentEntity.speedLimit} km/h · Máx: {currentEntity.maxSpeedToday} km/h
            </span>
          </div>
        </div>

        {/* Live Telemetry Cells */}
        <div className="flex items-center gap-4 text-xs">
          
          {/* Rumbo / Compass */}
          <div className="flex items-center gap-2 px-2.5 py-1.5 rounded-xl bg-slate-950/60 border border-slate-800">
            <Compass className="w-4 h-4 text-cyan-400" />
            <div className="flex flex-col">
              <span className="text-[10px] text-slate-400 font-medium">Rumbo</span>
              <span className="font-mono-nums font-bold text-slate-200">
                {Math.round(currentEntity.heading)}° {getCardinal(currentEntity.heading)}
              </span>
            </div>
          </div>

          {/* Altitud */}
          <div className="flex items-center gap-2 px-2.5 py-1.5 rounded-xl bg-slate-950/60 border border-slate-800 hidden sm:flex">
            <Mountain className="w-4 h-4 text-emerald-400" />
            <div className="flex flex-col">
              <span className="text-[10px] text-slate-400 font-medium">Altitud</span>
              <span className="font-mono-nums font-bold text-slate-200">
                {currentEntity.altitude} m
              </span>
            </div>
          </div>

          {/* Perrito: Pasos o Temperatura */}
          {isPuppy ? (
            <button
              onClick={onOpenPuppyModal}
              className="flex items-center gap-2 px-2.5 py-1.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-300 hover:bg-amber-500/20 transition-all cursor-pointer"
              title="Ver métricas de actividad de Max"
            >
              <Footprints className="w-4 h-4 text-amber-400" />
              <div className="flex flex-col text-left">
                <span className="text-[10px] text-amber-400 font-medium">Pasos Hoy</span>
                <span className="font-mono-nums font-bold text-white">
                  {currentEntity.stepsToday?.toLocaleString()}
                </span>
              </div>
            </button>
          ) : (
            <div className="flex items-center gap-2 px-2.5 py-1.5 rounded-xl bg-slate-950/60 border border-slate-800 hidden md:flex">
              <Gauge className="w-4 h-4 text-purple-400" />
              <div className="flex flex-col">
                <span className="text-[10px] text-slate-400 font-medium">Distancia Hoy</span>
                <span className="font-mono-nums font-bold text-slate-200">
                  {currentEntity.distanceTodayKm} km
                </span>
              </div>
            </div>
          )}

          {/* Batería Collar / Vehículo */}
          <div className="flex items-center gap-2 px-2.5 py-1.5 rounded-xl bg-slate-950/60 border border-slate-800">
            {currentEntity.batteryState === 'charging' ? (
              <BatteryCharging className="w-4 h-4 text-emerald-400 animate-pulse" />
            ) : (
              <Battery className={`w-4 h-4 ${currentEntity.battery > 20 ? 'text-emerald-400' : 'text-red-400'}`} />
            )}
            <div className="flex flex-col">
              <span className="text-[10px] text-slate-400 font-medium">
                {isPuppy ? 'Collar GPS' : 'Batería'}
              </span>
              <span className="font-mono-nums font-bold text-slate-200">
                {currentEntity.battery}%
              </span>
            </div>
          </div>

          {/* Camera Follow Toggle */}
          <button
            onClick={onToggleAutoCenter}
            className={`p-2 rounded-xl transition-all border flex items-center justify-center ${
              autoCenter
                ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/50 shadow-[0_0_12px_rgba(6,182,212,0.3)]'
                : 'bg-slate-950/60 text-slate-400 border-slate-800 hover:text-white'
            }`}
            title={autoCenter ? 'Cámara siguiendo al objetivo' : 'Activar seguimiento automático'}
          >
            <Crosshair className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Trip Simulation & History Scrub Player */}
      <div className="pointer-events-auto bg-slate-900/90 backdrop-blur-xl border border-slate-700/80 rounded-2xl px-4 py-2.5 shadow-2xl flex items-center gap-4">
        
        {/* Play / Pause / Step Controls */}
        <div className="flex items-center gap-1.5 shrink-0">
          <button
            onClick={onResetRoute}
            className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
            title="Reiniciar ruta al inicio"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={() => onScrub(Math.max(0, currentIndex - 1))}
            className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
            title="Punto anterior"
          >
            <SkipBack className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={onTogglePlay}
            className={`p-2.5 rounded-xl transition-all flex items-center justify-center shadow-lg ${
              isPlaying
                ? 'bg-amber-500 text-slate-950 hover:bg-amber-400'
                : 'bg-cyan-500 text-slate-950 hover:bg-cyan-400'
            }`}
            title={isPlaying ? 'Pausar simulación' : 'Iniciar reproducción / simulación de recorrido'}
          >
            {isPlaying ? <Pause className="w-4 h-4 fill-current" /> : <Play className="w-4 h-4 fill-current ml-0.5" />}
          </button>

          <button
            onClick={() => onScrub(Math.min(totalPoints - 1, currentIndex + 1))}
            className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
            title="Punto siguiente"
          >
            <SkipForward className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Timeline Slider */}
        <div className="flex-1 flex flex-col gap-1 min-w-0">
          <div className="flex items-center justify-between text-[11px] text-slate-400">
            <span className="font-mono-nums font-semibold text-cyan-400">
              {currentPoint?.timestamp || '10:00:00'}
            </span>
            <span className="truncate max-w-[200px] text-slate-300">
              {currentPoint?.streetName || 'Recorrido en curso'}
            </span>
            <span className="font-mono-nums">
              Punto {currentIndex + 1} de {totalPoints}
            </span>
          </div>

          <input
            type="range"
            min="0"
            max={totalPoints - 1}
            value={currentIndex}
            onChange={(e) => onScrub(parseInt(e.target.value, 10))}
            className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400 focus:outline-none"
          />
        </div>

        {/* Speed Multiplier (1x, 2x, 5x) */}
        <div className="flex items-center gap-1 bg-slate-950/70 border border-slate-800 rounded-xl p-1 shrink-0">
          {[1, 2, 5].map((spd) => (
            <button
              key={spd}
              onClick={() => onSetPlaybackSpeed(spd)}
              className={`px-2 py-1 rounded-lg text-[10px] font-bold font-mono-nums transition-colors ${
                playbackSpeed === spd
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {spd}x
            </button>
          ))}
        </div>

      </div>
    </div>
  );
};
