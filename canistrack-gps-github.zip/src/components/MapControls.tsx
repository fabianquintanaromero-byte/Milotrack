import React, { useState } from 'react';
import { 
  Compass, 
  Plus, 
  Minus, 
  Layers, 
  Crosshair, 
  Maximize2, 
  Minimize2, 
  Eye, 
  EyeOff, 
  Route, 
  Moon, 
  Globe, 
  Map as MapIcon, 
  Sparkles
} from 'lucide-react';
import { MapMode } from '../types/gps';

interface MapControlsProps {
  mapMode: MapMode;
  onSetMapMode: (mode: MapMode) => void;
  onZoomIn: () => void;
  onZoomOut: () => void;
  onResetNorth: () => void;
  onCenterTarget: () => void;
  autoCenter: boolean;
  showGeofences: boolean;
  onToggleGeofences: () => void;
  showRoutes: boolean;
  onToggleRoutes: () => void;
  bearing?: number;
}

export const MapControls: React.FC<MapControlsProps> = ({
  mapMode,
  onSetMapMode,
  onZoomIn,
  onZoomOut,
  onResetNorth,
  onCenterTarget,
  autoCenter,
  showGeofences,
  onToggleGeofences,
  showRoutes,
  onToggleRoutes,
  bearing = 0,
}) => {
  const [layersOpen, setLayersOpen] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().then(() => setIsFullscreen(true)).catch(() => {});
    } else {
      document.exitFullscreen().then(() => setIsFullscreen(false)).catch(() => {});
    }
  };

  return (
    <div className="absolute top-5 left-5 z-[500] flex flex-col gap-2">
      {/* Primary Navigation & Zoom Cluster matching Image 1 & 2 */}
      <div className="flex flex-col bg-slate-900/90 backdrop-blur-md border border-slate-700/80 rounded-xl shadow-2xl overflow-hidden divide-y divide-slate-800">
        
        {/* Compass / Bearing Arrow */}
        <button
          onClick={onResetNorth}
          title="Orientar mapa al Norte (0°)"
          className="p-3 text-slate-300 hover:text-cyan-400 hover:bg-slate-800/80 transition-all flex items-center justify-center group relative"
        >
          <Compass 
            className="w-5 h-5 transition-transform duration-300 group-hover:scale-110" 
            style={{ transform: `rotate(${-bearing}deg)` }}
          />
          <span className="sr-only">Norte</span>
        </button>

        {/* Zoom In */}
        <button
          onClick={onZoomIn}
          title="Acercar mapa (+)"
          className="p-3 text-slate-300 hover:text-cyan-400 hover:bg-slate-800/80 transition-all flex items-center justify-center"
        >
          <Plus className="w-5 h-5" />
          <span className="sr-only">Acercar</span>
        </button>

        {/* Zoom Out */}
        <button
          onClick={onZoomOut}
          title="Alejar mapa (-)"
          className="p-3 text-slate-300 hover:text-cyan-400 hover:bg-slate-800/80 transition-all flex items-center justify-center"
        >
          <Minus className="w-5 h-5" />
          <span className="sr-only">Alejar</span>
        </button>

        {/* Layers Switcher Button (matching Image 1 stack icon) */}
        <div className="relative">
          <button
            onClick={() => setLayersOpen(!layersOpen)}
            title="Cambiar capa de mapa (Modo Oscuro / Satélite)"
            className={`p-3 transition-all flex items-center justify-center w-full ${
              layersOpen ? 'text-cyan-400 bg-slate-800' : 'text-slate-300 hover:text-cyan-400 hover:bg-slate-800/80'
            }`}
          >
            <Layers className="w-5 h-5" />
            <span className="sr-only">Capas de mapa</span>
          </button>

          {/* Layer Switcher Popover */}
          {layersOpen && (
            <div className="absolute left-full top-0 ml-3 w-56 bg-slate-900/95 backdrop-blur-xl border border-slate-700/80 rounded-xl p-2.5 shadow-2xl flex flex-col gap-1.5 animate-in fade-in slide-in-from-left-2 duration-150">
              <div className="px-2 py-1 text-[11px] font-semibold text-slate-400 tracking-wider uppercase border-b border-slate-800">
                Modo de Mapa
              </div>

              {/* Modo Oscuro */}
              <button
                onClick={() => { onSetMapMode('dark'); setLayersOpen(false); }}
                className={`flex items-center gap-2.5 px-2.5 py-2 rounded-lg text-xs font-medium transition-colors ${
                  mapMode === 'dark'
                    ? 'bg-cyan-500/15 text-cyan-400 border border-cyan-500/40'
                    : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
                }`}
              >
                <Moon className="w-4 h-4 text-cyan-400" />
                <div className="text-left">
                  <div>Modo Oscuro</div>
                  <div className="text-[10px] text-slate-400 font-normal">Vector táctico nocturno</div>
                </div>
              </button>

              {/* Modo Satélite */}
              <button
                onClick={() => { onSetMapMode('satellite'); setLayersOpen(false); }}
                className={`flex items-center gap-2.5 px-2.5 py-2 rounded-lg text-xs font-medium transition-colors ${
                  mapMode === 'satellite'
                    ? 'bg-cyan-500/15 text-cyan-400 border border-cyan-500/40'
                    : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
                }`}
              >
                <Globe className="w-4 h-4 text-emerald-400" />
                <div className="text-left">
                  <div>Modo Satélite</div>
                  <div className="text-[10px] text-slate-400 font-normal">Fotografía aérea HD (Esri)</div>
                </div>
              </button>

              {/* Modo Híbrido */}
              <button
                onClick={() => { onSetMapMode('hybrid'); setLayersOpen(false); }}
                className={`flex items-center gap-2.5 px-2.5 py-2 rounded-lg text-xs font-medium transition-colors ${
                  mapMode === 'hybrid'
                    ? 'bg-cyan-500/15 text-cyan-400 border border-cyan-500/40'
                    : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
                }`}
              >
                <Sparkles className="w-4 h-4 text-amber-400" />
                <div className="text-left">
                  <div>Modo Híbrido</div>
                  <div className="text-[10px] text-slate-400 font-normal">Satélite + Nombres de calles</div>
                </div>
              </button>

              {/* Modo Calles */}
              <button
                onClick={() => { onSetMapMode('streets'); setLayersOpen(false); }}
                className={`flex items-center gap-2.5 px-2.5 py-2 rounded-lg text-xs font-medium transition-colors ${
                  mapMode === 'streets'
                    ? 'bg-cyan-500/15 text-cyan-400 border border-cyan-500/40'
                    : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
                }`}
              >
                <MapIcon className="w-4 h-4 text-purple-400" />
                <div className="text-left">
                  <div>Modo Calles</div>
                  <div className="text-[10px] text-slate-400 font-normal">Navegación urbana estándar</div>
                </div>
              </button>
            </div>
          )}
        </div>

        {/* Center on Target (Crosshair icon matching Image 1 & 2) */}
        <button
          onClick={onCenterTarget}
          title={autoCenter ? 'Cámara fijada en objetivo' : 'Centrar vista en objetivo'}
          className={`p-3 transition-all flex items-center justify-center ${
            autoCenter 
              ? 'text-cyan-400 bg-cyan-500/20 ring-1 ring-inset ring-cyan-500/50' 
              : 'text-slate-300 hover:text-cyan-400 hover:bg-slate-800/80'
          }`}
        >
          <Crosshair className="w-5 h-5" />
          <span className="sr-only">Centrar objetivo</span>
        </button>
      </div>

      {/* Secondary Controls (Geocercas, Rutas, Fullscreen) */}
      <div className="flex flex-col bg-slate-900/90 backdrop-blur-md border border-slate-700/80 rounded-xl shadow-2xl overflow-hidden divide-y divide-slate-800">
        
        {/* Toggle Geocercas */}
        <button
          onClick={onToggleGeofences}
          title={showGeofences ? 'Ocultar polígonos de geocercas' : 'Mostrar geocercas'}
          className={`p-3 transition-all flex items-center justify-center ${
            showGeofences ? 'text-amber-400 hover:bg-slate-800/80' : 'text-slate-500 hover:text-slate-300 hover:bg-slate-800/80'
          }`}
        >
          {showGeofences ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
        </button>

        {/* Toggle Rutas */}
        <button
          onClick={onToggleRoutes}
          title={showRoutes ? 'Ocultar trazado de rutas' : 'Mostrar trazado de rutas'}
          className={`p-3 transition-all flex items-center justify-center ${
            showRoutes ? 'text-cyan-400 hover:bg-slate-800/80' : 'text-slate-500 hover:text-slate-300 hover:bg-slate-800/80'
          }`}
        >
          <Route className="w-4 h-4" />
        </button>

        {/* Fullscreen Toggle */}
        <button
          onClick={toggleFullscreen}
          title="Pantalla completa"
          className="p-3 text-slate-300 hover:text-cyan-400 hover:bg-slate-800/80 transition-all flex items-center justify-center"
        >
          {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
        </button>
      </div>
    </div>
  );
};
