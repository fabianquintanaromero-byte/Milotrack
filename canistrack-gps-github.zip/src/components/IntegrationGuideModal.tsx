import React, { useState } from 'react';
import { 
  X, 
  Server, 
  Terminal, 
  Layers, 
  CheckCircle2, 
  Copy, 
  Check, 
  Play, 
  Radio, 
  Code, 
  Globe, 
  ArrowRight,
  Database,
  Download
} from 'lucide-react';
import { gpsApiClient } from '../services/gpsApiClient';

interface IntegrationGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const IntegrationGuideModal: React.FC<IntegrationGuideModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [activeTab, setActiveTab] = useState<'fastify' | 'nextjs' | 'sdk' | 'tester'>('tester');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  // Live API Tester State
  const [apiTesting, setApiTesting] = useState(false);
  const [testResult, setTestResult] = useState<any>(null);
  const [testLatency, setTestLatency] = useState<number | null>(null);
  const [lastTestedEndpoint, setLastTestedEndpoint] = useState<string>('');

  if (!isOpen) return null;

  const handleCopy = (code: string, key: string) => {
    navigator.clipboard.writeText(code);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const runTest = async (endpoint: 'health' | 'devices' | 'geofences' | 'command') => {
    setApiTesting(true);
    setLastTestedEndpoint(endpoint);
    const start = performance.now();
    try {
      let data: any;
      if (endpoint === 'health') {
        data = await gpsApiClient.getHealth();
      } else if (endpoint === 'devices') {
        data = await gpsApiClient.getDevices();
      } else if (endpoint === 'geofences') {
        data = await gpsApiClient.getGeofences();
      } else if (endpoint === 'command') {
        data = await gpsApiClient.sendCollarCommand('entity-puppy-max', 'beep', { durationMs: 1500 });
      }
      const end = performance.now();
      setTestLatency(Math.round(end - start));
      setTestResult(data);
    } catch (err: any) {
      setTestLatency(null);
      setTestResult({ error: err.message || 'Error de conexión con el backend' });
    } finally {
      setApiTesting(false);
    }
  };

  const fastifyCode = `// server/plugins/gpsPlugin.ts
import { FastifyPluginAsync } from 'fastify';

export const fastifyGpsPlugin: FastifyPluginAsync = async (fastify, opts) => {
  // GET /api/devices - Dispositivos GPS & Perrito Max
  fastify.get('/devices', async (request, reply) => {
    return {
      total: 4,
      devices: [
        {
          id: 'entity-puppy-max',
          name: 'Max (Perrito Castaño Claro)',
          type: 'pet',
          currentPosition: { lat: 19.3510, lng: -99.1620 },
          heading: 80,
          speed: 15,
          battery: 92,
          collarSerial: 'PAWPOINT-PRO-V2'
        }
      ]
    };
  });

  // POST /api/collar/command - Enviar comandos remotos (Beep / Luz)
  fastify.post('/collar/command', async (request, reply) => {
    const { deviceId, command } = request.body as any;
    // Envío a broker MQTT o gateway IoT
    return { success: true, deviceId, command, status: 'dispatched' };
  });

  // GET /api/geofences - Zonas de seguridad
  fastify.get('/geofences', async () => {
    return { geofences: [...] };
  });
};

// En tu server.ts principal de Fastify:
// import { fastifyGpsPlugin } from './plugins/gpsPlugin';
// app.register(fastifyGpsPlugin, { prefix: '/api' });`;

  const nextjsCode = `// app/gps-tracking/page.tsx (Next.js 13+ App Router)
"use client";

import dynamic from 'next/dynamic';

// Carga dinámica con ssr: false para inicializar Leaflet y Three.js solo en cliente
const CanisTrackGPS = dynamic(() => import('@/components/CanisTrackGPS'), {
  ssr: false,
  loading: () => (
    <div className="w-screen h-screen bg-[#0b0f17] flex items-center justify-center text-cyan-400 font-mono text-sm">
      Inicializando mapa satelital y modelo 3D...
    </div>
  ),
});

export default function GPSTrackingPage() {
  return (
    <main className="w-screen h-screen overflow-hidden">
      <CanisTrackGPS apiUrl={process.env.NEXT_PUBLIC_FASTIFY_API_URL || 'http://localhost:4000/api'} />
    </main>
  );
}`;

  const envCode = `# .env en tu proyecto Next.js
NEXT_PUBLIC_FASTIFY_API_URL=http://localhost:4000/api

# .env en tu servidor Node.js Fastify
FASTIFY_PORT=4000
CORS_ORIGIN=http://localhost:3000
DATABASE_URL=postgresql://user:password@localhost:5432/canisTrack`;

  return (
    <div className="fixed inset-0 z-[600] flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in duration-200">
      <div 
        className="w-full max-w-3xl bg-slate-900 border border-slate-700/80 rounded-3xl shadow-2xl overflow-hidden flex flex-col text-slate-100 max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-cyan-500/20 text-cyan-400 border border-cyan-500/40 flex items-center justify-center">
              <Server className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm sm:text-base font-bold text-white flex items-center gap-2">
                Integración en Plataforma Propia (Next.js + Fastify)
              </h3>
              <p className="text-[11px] text-slate-400">
                Backend Node.js con Fastify y Frontend React con Next.js
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="px-5 pt-3 border-b border-slate-800/80 flex items-center gap-2 overflow-x-auto text-xs font-semibold">
          <button
            onClick={() => setActiveTab('tester')}
            className={`pb-2.5 px-3 border-b-2 transition-all flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'tester'
                ? 'border-cyan-400 text-cyan-300'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Radio className="w-3.5 h-3.5 animate-pulse" />
            <span>Probador de API en Vivo</span>
          </button>

          <button
            onClick={() => setActiveTab('fastify')}
            className={`pb-2.5 px-3 border-b-2 transition-all flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'fastify'
                ? 'border-amber-400 text-amber-300'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Server className="w-3.5 h-3.5" />
            <span>Fastify Plugin (Node.js)</span>
          </button>

          <button
            onClick={() => setActiveTab('nextjs')}
            className={`pb-2.5 px-3 border-b-2 transition-all flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'nextjs'
                ? 'border-cyan-400 text-cyan-300'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>Next.js (App Router)</span>
          </button>

          <button
            onClick={() => setActiveTab('sdk')}
            className={`pb-2.5 px-3 border-b-2 transition-all flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'sdk'
                ? 'border-emerald-400 text-emerald-300'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Terminal className="w-3.5 h-3.5" />
            <span>Variables & .env</span>
          </button>
        </div>

        {/* Tab Content */}
        <div className="flex-1 overflow-y-auto p-5">
          {/* TAB 1: LIVE TESTER */}
          {activeTab === 'tester' && (
            <div className="space-y-4">
              <div className="p-3.5 rounded-2xl bg-cyan-950/30 border border-cyan-500/30 text-xs text-slate-300 flex items-start gap-3">
                <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold text-white">Servidor Node.js activo y conectado:</span>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    Este backend ya está respondiendo peticiones REST reales en <code>/api</code> compatibles 100% con los esquemas de Fastify. Haz clic en los botones de prueba para verificar respuestas y latencia.
                  </p>
                </div>
              </div>

              {/* Endpoint buttons */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                <button
                  onClick={() => runTest('health')}
                  disabled={apiTesting}
                  className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 hover:border-cyan-500 text-left transition-all"
                >
                  <div className="text-[10px] text-slate-500 uppercase font-mono">GET</div>
                  <div className="text-xs font-bold text-slate-200 truncate">/api/health</div>
                  <div className="text-[10px] text-emerald-400 mt-1">Estado de servicio</div>
                </button>

                <button
                  onClick={() => runTest('devices')}
                  disabled={apiTesting}
                  className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 hover:border-cyan-500 text-left transition-all"
                >
                  <div className="text-[10px] text-slate-500 uppercase font-mono">GET</div>
                  <div className="text-xs font-bold text-slate-200 truncate">/api/devices</div>
                  <div className="text-[10px] text-amber-400 mt-1">Perrito & Flota</div>
                </button>

                <button
                  onClick={() => runTest('geofences')}
                  disabled={apiTesting}
                  className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 hover:border-cyan-500 text-left transition-all"
                >
                  <div className="text-[10px] text-slate-500 uppercase font-mono">GET</div>
                  <div className="text-xs font-bold text-slate-200 truncate">/api/geofences</div>
                  <div className="text-[10px] text-cyan-400 mt-1">Polígonos CDMX</div>
                </button>

                <button
                  onClick={() => runTest('command')}
                  disabled={apiTesting}
                  className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 hover:border-cyan-500 text-left transition-all"
                >
                  <div className="text-[10px] text-slate-500 uppercase font-mono">POST</div>
                  <div className="text-xs font-bold text-slate-200 truncate">/collar/command</div>
                  <div className="text-[10px] text-rose-400 mt-1">Beep en Collar</div>
                </button>
              </div>

              {/* Response output viewer */}
              <div className="p-3 bg-slate-950 rounded-2xl border border-slate-800">
                <div className="flex items-center justify-between text-xs text-slate-400 mb-2 pb-2 border-b border-slate-850">
                  <span className="font-mono">
                    Respuesta: {lastTestedEndpoint ? `/api/${lastTestedEndpoint}` : 'Selecciona un endpoint arriba'}
                  </span>
                  {testLatency !== null && (
                    <span className="font-mono text-emerald-400 font-bold">
                      Latencia: {testLatency} ms
                    </span>
                  )}
                </div>

                <pre className="text-[11px] font-mono text-cyan-300 overflow-x-auto p-2 bg-slate-900/60 rounded-xl max-h-48">
                  {apiTesting
                    ? 'Consultando servidor Node.js...'
                    : testResult
                    ? JSON.stringify(testResult, null, 2)
                    : '// Haz clic en un botón de prueba para ejecutar la petición HTTP'}
                </pre>
              </div>
            </div>
          )}

          {/* TAB 2: FASTIFY CODE */}
          {activeTab === 'fastify' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span>Plugin Fastify listo para copiar en tu backend Node.js:</span>
                <button
                  onClick={() => handleCopy(fastifyCode, 'fastify')}
                  className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 rounded-lg text-slate-200 flex items-center gap-1.5 transition-colors text-[11px]"
                >
                  {copiedKey === 'fastify' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedKey === 'fastify' ? 'Copiado' : 'Copiar Plugin'}</span>
                </button>
              </div>
              <pre className="text-[11px] font-mono text-amber-200/90 bg-slate-950 p-3.5 rounded-2xl border border-slate-800 overflow-x-auto leading-relaxed max-h-80">
                {fastifyCode}
              </pre>
            </div>
          )}

          {/* TAB 3: NEXT.JS CODE */}
          {activeTab === 'nextjs' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span>Página Next.js (App Router con ssr: false para Leaflet y Three.js):</span>
                <button
                  onClick={() => handleCopy(nextjsCode, 'nextjs')}
                  className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 rounded-lg text-slate-200 flex items-center gap-1.5 transition-colors text-[11px]"
                >
                  {copiedKey === 'nextjs' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedKey === 'nextjs' ? 'Copiado' : 'Copiar Código'}</span>
                </button>
              </div>
              <pre className="text-[11px] font-mono text-cyan-200/90 bg-slate-950 p-3.5 rounded-2xl border border-slate-800 overflow-x-auto leading-relaxed max-h-80">
                {nextjsCode}
              </pre>
            </div>
          )}

          {/* TAB 4: ENV & CONFIG */}
          {activeTab === 'sdk' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span>Configuración de entorno para Next.js y Fastify:</span>
                <button
                  onClick={() => handleCopy(envCode, 'env')}
                  className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 rounded-lg text-slate-200 flex items-center gap-1.5 transition-colors text-[11px]"
                >
                  {copiedKey === 'env' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedKey === 'env' ? 'Copiado' : 'Copiar .env'}</span>
                </button>
              </div>
              <pre className="text-[11px] font-mono text-emerald-200/90 bg-slate-950 p-3.5 rounded-2xl border border-slate-800 overflow-x-auto leading-relaxed max-h-80">
                {envCode}
              </pre>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-950/80 border-t border-slate-800 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <a
              href="/api/download-zip"
              download="canistrack-gps-github.zip"
              className="px-4 py-2 bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-400 hover:to-cyan-400 text-slate-950 font-extrabold text-xs rounded-xl flex items-center gap-2 shadow-lg transition-transform hover:scale-[1.02] cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>Descargar ZIP para GitHub</span>
            </a>
            <span className="text-[11px] text-slate-400 font-mono hidden sm:inline">
              Incluye Next.js, Fastify y README.md
            </span>
          </div>

          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-white rounded-xl transition-colors"
          >
            Cerrar
          </button>
        </div>
      </div>
    </div>
  );
};
