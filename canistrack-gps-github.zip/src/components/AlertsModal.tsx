import React from 'react';
import { X, AlertTriangle, ShieldAlert, CheckCheck, Clock, MapPin } from 'lucide-react';
import { GPSAlert } from '../types/gps';

interface AlertsModalProps {
  alerts: GPSAlert[];
  isOpen: boolean;
  onClose: () => void;
  onMarkAllAsRead: () => void;
  onCenterAlert: (coords: { lat: number; lng: number }) => void;
}

export const AlertsModal: React.FC<AlertsModalProps> = ({
  alerts,
  isOpen,
  onClose,
  onMarkAllAsRead,
  onCenterAlert,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[600] flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div 
        className="w-full max-w-lg bg-slate-900 border border-slate-700/80 rounded-3xl shadow-2xl overflow-hidden flex flex-col text-slate-100 max-h-[85vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-red-500/20 text-red-400 border border-red-500/40 flex items-center justify-center">
              <ShieldAlert className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">
                Alertas del Sistema GPS
              </h3>
              <p className="text-[11px] text-slate-400">
                Eventos de geocercas, velocidad y estado
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onMarkAllAsRead}
              className="text-xs text-cyan-400 hover:text-cyan-300 font-medium px-2 py-1"
            >
              Marcar leídas
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Alerts list */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {alerts.map((alt) => (
            <div
              key={alt.id}
              className={`p-3.5 rounded-2xl border transition-all text-left ${
                alt.severity === 'critical'
                  ? 'bg-red-950/20 border-red-500/40 shadow-sm'
                  : alt.severity === 'warning'
                  ? 'bg-amber-950/20 border-amber-500/40 shadow-sm'
                  : 'bg-slate-950/50 border-slate-800'
              }`}
            >
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-2">
                  <span
                    className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                      alt.severity === 'critical'
                        ? 'bg-red-500 text-white'
                        : alt.severity === 'warning'
                        ? 'bg-amber-500 text-slate-950'
                        : 'bg-cyan-500 text-slate-950'
                    }`}
                  >
                    {alt.severity}
                  </span>
                  <h4 className="text-xs font-bold text-white">
                    {alt.title}
                  </h4>
                </div>

                <span className="text-[10px] text-slate-400 font-mono-nums flex items-center gap-1">
                  <Clock className="w-3 h-3" />
                  {alt.timestamp}
                </span>
              </div>

              <p className="text-xs text-slate-300 mt-1.5 leading-relaxed">
                {alt.description}
              </p>

              <div className="mt-3 pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs">
                <span className="text-[11px] text-slate-400 font-medium">
                  {alt.entityName}
                </span>

                <button
                  onClick={() => {
                    onCenterAlert(alt.coordinates);
                    onClose();
                  }}
                  className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-cyan-300 text-[11px] font-semibold flex items-center gap-1 transition-colors"
                >
                  <MapPin className="w-3 h-3" /> Ver en mapa
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Footer */}
        <div className="p-3 bg-slate-950/80 border-t border-slate-800 text-right">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-white rounded-xl transition-colors"
          >
            Cerrar
          </button>
        </div>
      </div>
    </div>
  );
};
