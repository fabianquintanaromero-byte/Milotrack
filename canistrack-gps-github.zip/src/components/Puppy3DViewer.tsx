import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { RotateCw, Play, Pause, ZoomIn, ZoomOut, Sparkles } from 'lucide-react';

interface Puppy3DViewerProps {
  speed?: number; // km/h
  isMoving?: boolean;
  collarLedActive?: boolean;
  onBuzzerHeard?: boolean;
  interactive?: boolean;
  heightClass?: string;
  showControls?: boolean;
}

export const Puppy3DViewer: React.FC<Puppy3DViewerProps> = ({
  speed = 15,
  isMoving = true,
  collarLedActive = true,
  onBuzzerHeard = false,
  interactive = true,
  heightClass = 'h-64 sm:h-72',
  showControls = true,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [animationState, setAnimationState] = useState<'walk' | 'trot' | 'sit'>(isMoving ? 'walk' : 'sit');
  const [autoRotate, setAutoRotate] = useState(true);

  // References to 3D objects
  const sceneRef = useRef<THREE.Scene | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const dogRef = useRef<THREE.Group | null>(null);

  // Limb refs for animation
  const limbsRef = useRef<{
    legFL: THREE.Group;
    legFR: THREE.Group;
    legBL: THREE.Group;
    legBR: THREE.Group;
    tail: THREE.Group;
    head: THREE.Group;
    earL: THREE.Group;
    earR: THREE.Group;
    body: THREE.Group;
    collarLed: THREE.Mesh;
  } | null>(null);

  const animFrameIdRef = useRef<number | null>(null);
  const isDraggingRef = useRef(false);
  const prevMousePosRef = useRef({ x: 0, y: 0 });

  useEffect(() => {
    if (!containerRef.current) return;
    const container = containerRef.current;
    const width = container.clientWidth || 320;
    const height = container.clientHeight || 280;

    // 1. Scene
    const scene = new THREE.Scene();
    sceneRef.current = scene;

    // 2. Camera
    const camera = new THREE.PerspectiveCamera(38, width / height, 0.1, 100);
    camera.position.set(3.6, 2.4, 4.2);
    camera.lookAt(0, 0.5, 0);
    cameraRef.current = camera;

    // 3. Renderer with antialias and alpha
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    rendererRef.current = renderer;

    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    // 4. Lighting (Three-point studio lighting as required by design guide)
    const ambientLight = new THREE.AmbientLight(0xfff5ea, 1.2);
    scene.add(ambientLight);

    // Warm Key Light
    const keyLight = new THREE.DirectionalLight(0xfffaed, 2.0);
    keyLight.position.set(5, 7, 6);
    keyLight.castShadow = true;
    keyLight.shadow.mapSize.width = 1024;
    keyLight.shadow.mapSize.height = 1024;
    scene.add(keyLight);

    // Cool Rim / Back Light (separates dog from dark background)
    const rimLight = new THREE.DirectionalLight(0x38bdf8, 1.4);
    rimLight.position.set(-5, 4, -4);
    scene.add(rimLight);

    // Soft Fill Light
    const fillLight = new THREE.PointLight(0xf59e0b, 1.0, 10);
    fillLight.position.set(0, -1, 3);
    scene.add(fillLight);

    // 5. Build Light Brown Puppy Character
    const dog = new THREE.Group();
    dogRef.current = dog;
    dog.position.y = 0.2;
    scene.add(dog);

    // Materials - Golden Caramel Puppy Fur
    const furMainMat = new THREE.MeshStandardMaterial({
      color: 0xde9538, // Light brown / golden caramel
      roughness: 0.75,
      metalness: 0.05,
    });

    const furLightMat = new THREE.MeshStandardMaterial({
      color: 0xfef0c7, // Creamy tan muzzle/belly
      roughness: 0.8,
    });

    const furDeepMat = new THREE.MeshStandardMaterial({
      color: 0xb45309, // Slightly deeper caramel for ears
      roughness: 0.8,
    });

    const noseMat = new THREE.MeshStandardMaterial({
      color: 0x18181b, // Wet black nose
      roughness: 0.2,
      metalness: 0.1,
    });

    const eyeMat = new THREE.MeshStandardMaterial({
      color: 0x09090b,
      roughness: 0.1,
    });

    const collarMat = new THREE.MeshStandardMaterial({
      color: 0x0284c7, // Cyan/Blue collar
      roughness: 0.3,
      metalness: 0.2,
    });

    const ledMat = new THREE.MeshStandardMaterial({
      color: 0x38bdf8,
      emissive: 0x38bdf8,
      emissiveIntensity: 2.5,
    });

    // --- Body Group ---
    const bodyGroup = new THREE.Group();
    dog.add(bodyGroup);

    // Torso (elongated rounded capsule/box)
    const torsoGeo = new THREE.CylinderGeometry(0.52, 0.48, 1.25, 16);
    torsoGeo.rotateZ(Math.PI / 2);
    const torsoMesh = new THREE.Mesh(torsoGeo, furMainMat);
    torsoMesh.castShadow = true;
    bodyGroup.add(torsoMesh);

    // Chest / Belly highlight
    const chestGeo = new THREE.SphereGeometry(0.48, 16, 16);
    chestGeo.scale(1.1, 0.9, 0.85);
    const chestMesh = new THREE.Mesh(chestGeo, furLightMat);
    chestMesh.position.set(0.4, -0.05, 0);
    bodyGroup.add(chestMesh);

    // --- Head Group ---
    const headGroup = new THREE.Group();
    headGroup.position.set(0.72, 0.55, 0);
    dog.add(headGroup);

    // Skull
    const skullGeo = new THREE.SphereGeometry(0.46, 20, 20);
    skullGeo.scale(1.05, 1.0, 0.95);
    const skullMesh = new THREE.Mesh(skullGeo, furMainMat);
    skullMesh.castShadow = true;
    headGroup.add(skullMesh);

    // Snout / Muzzle
    const snoutGeo = new THREE.CylinderGeometry(0.2, 0.26, 0.42, 16);
    snoutGeo.rotateZ(-Math.PI / 2);
    const snoutMesh = new THREE.Mesh(snoutGeo, furLightMat);
    snoutMesh.position.set(0.35, -0.1, 0);
    snoutMesh.castShadow = true;
    headGroup.add(snoutMesh);

    // Cute Black Nose
    const noseGeo = new THREE.SphereGeometry(0.09, 12, 12);
    noseGeo.scale(1.2, 0.9, 1.0);
    const noseMesh = new THREE.Mesh(noseGeo, noseMat);
    noseMesh.position.set(0.58, -0.06, 0);
    headGroup.add(noseMesh);

    // Eyes
    const eyeGeo = new THREE.SphereGeometry(0.065, 12, 12);
    // Left eye
    const eyeL = new THREE.Mesh(eyeGeo, eyeMat);
    eyeL.position.set(0.36, 0.1, 0.22);
    headGroup.add(eyeL);
    // Right eye
    const eyeR = new THREE.Mesh(eyeGeo, eyeMat);
    eyeR.position.set(0.36, 0.1, -0.22);
    headGroup.add(eyeR);

    // Cute specular eye sparkles
    const sparkleMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
    const sparkleGeo = new THREE.SphereGeometry(0.02, 8, 8);
    const sparkleL = new THREE.Mesh(sparkleGeo, sparkleMat);
    sparkleL.position.set(0.4, 0.12, 0.23);
    headGroup.add(sparkleL);
    const sparkleR = new THREE.Mesh(sparkleGeo, sparkleMat);
    sparkleR.position.set(0.4, 0.12, -0.21);
    headGroup.add(sparkleR);

    // Floppy Caramel Ears
    // Left Ear
    const earLGroup = new THREE.Group();
    earLGroup.position.set(0.0, 0.25, 0.38);
    headGroup.add(earLGroup);
    const earGeo = new THREE.ConeGeometry(0.22, 0.65, 12);
    earGeo.rotateX(Math.PI);
    earGeo.scale(0.8, 1.0, 0.3);
    const earLMesh = new THREE.Mesh(earGeo, furDeepMat);
    earLMesh.position.set(0, -0.28, 0.05);
    earLMesh.rotation.z = 0.2;
    earLGroup.add(earLMesh);

    // Right Ear
    const earRGroup = new THREE.Group();
    earRGroup.position.set(0.0, 0.25, -0.38);
    headGroup.add(earRGroup);
    const earRMesh = new THREE.Mesh(earGeo, furDeepMat);
    earRMesh.position.set(0, -0.28, -0.05);
    earRMesh.rotation.z = 0.2;
    earRGroup.add(earRMesh);

    // --- High-Tech GPS Collar & Tag ---
    const collarGeo = new THREE.TorusGeometry(0.42, 0.065, 12, 24);
    collarGeo.rotateY(Math.PI / 2);
    const collarMesh = new THREE.Mesh(collarGeo, collarMat);
    collarMesh.position.set(0.46, 0.2, 0);
    collarMesh.rotation.z = -0.4;
    dog.add(collarMesh);

    // GPS Tag Unit on Collar
    const tagGeo = new THREE.BoxGeometry(0.12, 0.14, 0.16);
    const tagMat = new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.2, metalness: 0.8 });
    const tagMesh = new THREE.Mesh(tagGeo, tagMat);
    tagMesh.position.set(0.58, 0.05, 0);
    dog.add(tagMesh);

    // Glowing LED on Tag
    const ledGeo = new THREE.SphereGeometry(0.035, 10, 10);
    const ledMesh = new THREE.Mesh(ledGeo, ledMat);
    ledMesh.position.set(0.65, 0.05, 0);
    dog.add(ledMesh);

    // --- Tail Group ---
    const tailGroup = new THREE.Group();
    tailGroup.position.set(-0.62, 0.18, 0);
    dog.add(tailGroup);

    const tailGeo = new THREE.CylinderGeometry(0.08, 0.14, 0.65, 12);
    tailGeo.rotateZ(Math.PI / 3.5);
    const tailMesh = new THREE.Mesh(tailGeo, furMainMat);
    tailMesh.position.set(-0.25, 0.2, 0);
    tailMesh.castShadow = true;
    tailGroup.add(tailMesh);

    // --- 4 Animated Legs with Hip/Shoulder Pivots ---
    const createLeg = (x: number, y: number, z: number) => {
      const legPivot = new THREE.Group();
      legPivot.position.set(x, y, z);
      dog.add(legPivot);

      // Upper leg
      const legGeo = new THREE.CylinderGeometry(0.12, 0.09, 0.58, 12);
      const legMesh = new THREE.Mesh(legGeo, furMainMat);
      legMesh.position.set(0, -0.28, 0);
      legMesh.castShadow = true;
      legPivot.add(legMesh);

      // Paw (foot pad)
      const pawGeo = new THREE.SphereGeometry(0.11, 10, 10);
      pawGeo.scale(1.3, 0.7, 1.0);
      const pawMesh = new THREE.Mesh(pawGeo, furLightMat);
      pawMesh.position.set(0.06, -0.56, 0);
      legPivot.add(pawMesh);

      return legPivot;
    };

    const legFL = createLeg(0.44, -0.15, 0.32);
    const legFR = createLeg(0.44, -0.15, -0.32);
    const legBL = createLeg(-0.44, -0.18, 0.3);
    const legBR = createLeg(-0.44, -0.18, -0.3);

    // Save references for animation loop
    limbsRef.current = {
      legFL,
      legFR,
      legBL,
      legBR,
      tail: tailGroup,
      head: headGroup,
      earL: earLGroup,
      earR: earRGroup,
      body: bodyGroup,
      collarLed: ledMesh,
    };

    // --- Ground Pedestal & Radar Rings ---
    const groundGeo = new THREE.CylinderGeometry(1.9, 2.1, 0.08, 32);
    const groundMat = new THREE.MeshStandardMaterial({
      color: 0x0f172a,
      roughness: 0.85,
      metalness: 0.1,
    });
    const groundMesh = new THREE.Mesh(groundGeo, groundMat);
    groundMesh.position.y = -0.76;
    groundMesh.receiveShadow = true;
    scene.add(groundMesh);

    // Radar Ring 1
    const ring1Geo = new THREE.RingGeometry(1.4, 1.44, 48);
    ring1Geo.rotateX(-Math.PI / 2);
    const ring1Mat = new THREE.MeshBasicMaterial({ color: 0x38bdf8, opacity: 0.45, transparent: true });
    const ring1 = new THREE.Mesh(ring1Geo, ring1Mat);
    ring1.position.y = -0.71;
    scene.add(ring1);

    // Radar Ring 2
    const ring2Geo = new THREE.RingGeometry(1.8, 1.83, 48);
    ring2Geo.rotateX(-Math.PI / 2);
    const ring2Mat = new THREE.MeshBasicMaterial({ color: 0x0284c7, opacity: 0.25, transparent: true });
    const ring2 = new THREE.Mesh(ring2Geo, ring2Mat);
    ring2.position.y = -0.71;
    scene.add(ring2);

    // Forward Directional 3D Navigation Arrow on Ground
    const arrowShape = new THREE.Shape();
    arrowShape.moveTo(0, 0.5);
    arrowShape.lineTo(0.25, -0.15);
    arrowShape.lineTo(0.08, -0.05);
    arrowShape.lineTo(0.08, -0.4);
    arrowShape.lineTo(-0.08, -0.4);
    arrowShape.lineTo(-0.08, -0.05);
    arrowShape.lineTo(-0.25, -0.15);
    arrowShape.closePath();

    const arrowGeo = new THREE.ShapeGeometry(arrowShape);
    arrowGeo.rotateX(-Math.PI / 2);
    arrowGeo.rotateY(Math.PI / 2);
    const arrowMat = new THREE.MeshBasicMaterial({ color: 0x38bdf8, opacity: 0.8, transparent: true });
    const arrowMesh = new THREE.Mesh(arrowGeo, arrowMat);
    arrowMesh.position.set(0.9, -0.7, 0);
    arrowMesh.scale.set(1.2, 1.2, 1.2);
    scene.add(arrowMesh);

    // --- Interactive Orbit Controls (Pointer Drag) ---
    let cameraAngle = 0.8;
    let cameraDist = 5.2;
    let cameraElevation = 2.4;

    const handlePointerDown = (e: MouseEvent | TouchEvent) => {
      isDraggingRef.current = true;
      const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
      const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;
      prevMousePosRef.current = { x: clientX, y: clientY };
    };

    const handlePointerMove = (e: MouseEvent | TouchEvent) => {
      if (!isDraggingRef.current) return;
      const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
      const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;

      const deltaX = clientX - prevMousePosRef.current.x;
      const deltaY = clientY - prevMousePosRef.current.y;

      cameraAngle -= deltaX * 0.01;
      cameraElevation = Math.max(0.5, Math.min(5.0, cameraElevation + deltaY * 0.01));

      prevMousePosRef.current = { x: clientX, y: clientY };
    };

    const handlePointerUp = () => {
      isDraggingRef.current = false;
    };

    if (interactive) {
      container.addEventListener('mousedown', handlePointerDown);
      window.addEventListener('mousemove', handlePointerMove);
      window.addEventListener('mouseup', handlePointerUp);

      container.addEventListener('touchstart', handlePointerDown);
      window.addEventListener('touchmove', handlePointerMove);
      window.addEventListener('touchend', handlePointerUp);
    }

    // --- Animation Loop ---
    let clock = new THREE.Clock();

    const animate = () => {
      animFrameIdRef.current = requestAnimationFrame(animate);

      const elapsed = clock.getElapsedTime();
      const limbs = limbsRef.current;

      // Update camera position from orbit coordinates
      if (autoRotate && !isDraggingRef.current) {
        cameraAngle += 0.006;
      }

      camera.position.x = Math.sin(cameraAngle) * cameraDist;
      camera.position.z = Math.cos(cameraAngle) * cameraDist;
      camera.position.y = cameraElevation;
      camera.lookAt(0, 0.3, 0);

      // Radar rings gentle rotation
      ring1.rotation.y = elapsed * 0.4;
      ring2.rotation.y = -elapsed * 0.25;

      if (limbs) {
        // Collar LED pulsation
        const ledBrightness = collarLedActive ? (Math.sin(elapsed * 6) > 0 ? 3.0 : 0.8) : 0;
        (limbs.collarLed.material as THREE.MeshStandardMaterial).emissiveIntensity = ledBrightness;

        // Tail Wagging (Happy Puppy!)
        const tailFreq = animationState === 'trot' ? 14 : 9;
        limbs.tail.rotation.z = Math.sin(elapsed * tailFreq) * 0.45;
        limbs.tail.rotation.y = Math.cos(elapsed * (tailFreq / 2)) * 0.25;

        // Ear Bounce
        const earBounce = Math.sin(elapsed * 8) * 0.08;
        limbs.earL.rotation.z = 0.15 + earBounce;
        limbs.earR.rotation.z = 0.15 - earBounce;

        // Walk / Trot Cycle
        if (animationState === 'walk' || animationState === 'trot') {
          const walkFreq = animationState === 'trot' ? 12 : 7.5;
          const strideAmp = animationState === 'trot' ? 0.65 : 0.45;

          // Opposite diagonal leg pairs stride together (quadruped walk gait)
          limbs.legFL.rotation.z = Math.sin(elapsed * walkFreq) * strideAmp;
          limbs.legBR.rotation.z = Math.sin(elapsed * walkFreq) * (strideAmp * 0.9);

          limbs.legFR.rotation.z = -Math.sin(elapsed * walkFreq) * strideAmp;
          limbs.legBL.rotation.z = -Math.sin(elapsed * walkFreq) * (strideAmp * 0.9);

          // Subtle body vertical bob & sway
          dog.position.y = 0.2 + Math.abs(Math.sin(elapsed * walkFreq)) * 0.06;
          limbs.body.rotation.z = Math.sin(elapsed * walkFreq) * 0.04;
          limbs.head.position.y = 0.55 + Math.sin(elapsed * (walkFreq * 2)) * 0.03;
          limbs.head.rotation.z = Math.sin(elapsed * walkFreq) * 0.03;
        } else {
          // Sitting / Resting Pose
          limbs.legFL.rotation.z = 0;
          limbs.legFR.rotation.z = 0;
          limbs.legBL.rotation.z = -0.7; // folded hind legs
          limbs.legBR.rotation.z = -0.7;
          dog.position.y = 0.05;
          limbs.body.rotation.z = 0.2;
          limbs.head.position.y = 0.45;
        }

        // Buzzer alert reaction: Puppy perks up head!
        if (onBuzzerHeard) {
          limbs.head.rotation.y = Math.sin(elapsed * 12) * 0.35;
          limbs.head.rotation.z = 0.25;
        }
      }

      renderer.render(scene, camera);
    };

    animate();

    // Resize handler
    const handleResize = () => {
      if (!containerRef.current || !rendererRef.current || !cameraRef.current) return;
      const newWidth = containerRef.current.clientWidth;
      const newHeight = containerRef.current.clientHeight;
      cameraRef.current.aspect = newWidth / newHeight;
      cameraRef.current.updateProjectionMatrix();
      rendererRef.current.setSize(newWidth, newHeight);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      if (animFrameIdRef.current) cancelAnimationFrame(animFrameIdRef.current);
      if (interactive) {
        container.removeEventListener('mousedown', handlePointerDown);
        window.removeEventListener('mousemove', handlePointerMove);
        window.removeEventListener('mouseup', handlePointerUp);
        container.removeEventListener('touchstart', handlePointerDown);
        window.removeEventListener('touchmove', handlePointerMove);
        window.removeEventListener('touchend', handlePointerUp);
      }
      renderer.dispose();
    };
  }, [animationState, autoRotate, collarLedActive, onBuzzerHeard, interactive]);

  return (
    <div className="relative w-full overflow-hidden select-none">
      {/* 3D WebGL Canvas Container */}
      <div 
        ref={containerRef} 
        className={`w-full ${heightClass} cursor-grab active:cursor-grabbing flex items-center justify-center`} 
      />

      {/* Floating 3D Control Strip */}
      {showControls && (
        <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between pointer-events-none">
          {/* Gait Switcher (Caminar / Trotar / Sentado) */}
          <div className="pointer-events-auto flex items-center gap-1 bg-slate-950/85 backdrop-blur-md border border-slate-800 rounded-xl p-1 shadow-lg text-[11px] font-bold">
            <button
              onClick={() => setAnimationState('walk')}
              className={`px-2.5 py-1 rounded-lg transition-colors ${
                animationState === 'walk'
                  ? 'bg-amber-500 text-slate-950 shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Caminar
            </button>
            <button
              onClick={() => setAnimationState('trot')}
              className={`px-2.5 py-1 rounded-lg transition-colors ${
                animationState === 'trot'
                  ? 'bg-amber-500 text-slate-950 shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Trotar
            </button>
            <button
              onClick={() => setAnimationState('sit')}
              className={`px-2.5 py-1 rounded-lg transition-colors ${
                animationState === 'sit'
                  ? 'bg-amber-500 text-slate-950 shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Sentado
            </button>
          </div>

          {/* Camera Auto-Rotate Toggle */}
          <div className="pointer-events-auto flex items-center gap-1 bg-slate-950/85 backdrop-blur-md border border-slate-800 rounded-xl p-1 shadow-lg">
            <button
              onClick={() => setAutoRotate(!autoRotate)}
              className={`p-1.5 rounded-lg transition-colors ${
                autoRotate ? 'text-cyan-400 bg-cyan-950/50' : 'text-slate-400 hover:text-white'
              }`}
              title={autoRotate ? 'Pausar rotación 360°' : 'Activar giro automático 360°'}
            >
              <RotateCw className={`w-3.5 h-3.5 ${autoRotate ? 'animate-spin' : ''}`} style={{ animationDuration: '6s' }} />
            </button>
          </div>
        </div>
      )}

      {/* Helper text badge */}
      <div className="absolute top-2.5 left-3 text-[10px] text-amber-400/90 font-semibold flex items-center gap-1 pointer-events-none bg-slate-950/70 backdrop-blur-md px-2 py-0.5 rounded-md border border-amber-500/20">
        <Sparkles className="w-3 h-3 text-amber-400" />
        <span>Modelo 3D Interactivo · Arrastra para girar</span>
      </div>
    </div>
  );
};
