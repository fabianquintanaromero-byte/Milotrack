import React, { useState } from 'react';
import { 
  X, 
  Dog, 
  Battery, 
  Activity, 
  Footprints, 
  Volume2, 
  Lightbulb, 
  ShieldCheck, 
  MapPin, 
  Radio, 
  Heart,
  Phone,
  Clock,
  Check,
  Box
} from 'lucide-react';
import { TrackedEntity } from '../types/gps';
import { Puppy3DViewer } from './Puppy3DViewer';

interface PuppyDetailModalProps {
  puppy: TrackedEntity;
  isOpen: boolean;
  onClose: () => void;
  onCenterMap: () => void;
}

export const PuppyDetailModal: React.FC<PuppyDetailModalProps> = ({
  puppy,
  isOpen,
  onClose,
  onCenterMap,
}) => {
  const [buzzerActive, setBuzzerActive] = useState(false);
  const [ledActive, setLedActive] = useState(true);
  const [liveModeActive, setLiveModeActive] = useState(true);

  if (!isOpen) return null;

  const triggerBuzzer = () => {
    setBuzzerActive(true);
    // Play subtle audio tone using Web Audio API
    try {
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(880, audioCtx.currentTime);
      gain.gain.setValueAtTime(0.15, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.6);
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.start();
      osc.stop(audioCtx.currentTime + 0.6);
    } catch (e) {
      // Audio fallback
    }

    setTimeout(() => setBuzzerActive(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-[600] flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in duration-200">
      <div 
        className="w-full max-w-lg bg-slate-900 border border-slate-700/80 rounded-3xl shadow-2xl overflow-hidden flex flex-col text-slate-100 animate-in zoom-in-95 duration-200 max-h-[92vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header with Live 3D Puppy Walking Scene */}
        <div className="relative bg-gradient-to-b from-slate-950 via-slate-900 to-slate-900 border-b border-slate-800">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 z-20 p-2 rounded-full bg-slate-900/80 text-slate-400 hover:text-white hover:bg-slate-800 transition-colors shadow-lg"
          >
            <X className="w-5 h-5" />
          </button>

          {/* Interactive 3D Puppy Model in motion */}
          <div className="w-full">
            <Puppy3DViewer 
              speed={puppy.speed}
              isMoving={puppy.status === 'moving'}
              collarLedActive={ledActive}
              onBuzzerHeard={buzzerActive}
              interactive={true}
              heightClass="h-64 sm:h-72"
              showControls={true}
            />
          </div>

          {/* Overlay Dog Tag */}
          <div className="px-6 pb-4 pt-1 flex items-center justify-between border-t border-slate-800/60 bg-slate-900/60 backdrop-blur-sm">
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-extrabold text-white flex items-center gap-2">
                  <span>🐕</span> Max
                </h2>
                <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40">
                  Modelo 3D Animado
                </span>
              </div>
              <p className="text-[11px] text-slate-400 mt-0.5">
                Golden Retriever Pup · Collar Inteligente PawPoint Pro V2
              </p>
            </div>

            <div className="flex items-center gap-1.5 text-[11px] text-emerald-400 font-medium">
              <Radio className="w-3 h-3 animate-pulse" />
              <span className="hidden sm:inline">Rastreo Activo</span>
            </div>
          </div>
        </div>

        {/* Telemetry Metrics Grid */}
        <div className="p-6 space-y-5">
          <div className="grid grid-cols-3 gap-3">
            {/* Battery */}
            <div className="p-3 bg-slate-950/60 border border-slate-800 rounded-2xl flex flex-col">
              <div className="flex items-center justify-between text-slate-400 text-xs mb-1">
                <span>Batería</span>
                <Battery className="w-4 h-4 text-emerald-400" />
              </div>
              <span className="text-lg font-bold font-mono-nums text-white">
                {puppy.battery}%
              </span>
              <span className="text-[10px] text-slate-500">
                ~68h autonomía
              </span>
            </div>

            {/* Steps / Actividad */}
            <div className="p-3 bg-slate-950/60 border border-slate-800 rounded-2xl flex flex-col">
              <div className="flex items-center justify-between text-slate-400 text-xs mb-1">
                <span>Pasos Hoy</span>
                <Footprints className="w-4 h-4 text-amber-400" />
              </div>
              <span className="text-lg font-bold font-mono-nums text-white">
                {puppy.stepsToday?.toLocaleString()}
              </span>
              <span className="text-[10px] text-emerald-400 font-medium">
                Activo & Saludable
              </span>
            </div>

            {/* Temperatura */}
            <div className="p-3 bg-slate-950/60 border border-slate-800 rounded-2xl flex flex-col">
              <div className="flex items-center justify-between text-slate-400 text-xs mb-1">
                <span>Temperatura</span>
                <Activity className="w-4 h-4 text-cyan-400" />
              </div>
              <span className="text-lg font-bold font-mono-nums text-white">
                {puppy.temperature}°C
              </span>
              <span className="text-[10px] text-slate-500">
                Collar Térmico
              </span>
            </div>
          </div>

          {/* Current Safe Zone and Location */}
          <div className="p-3.5 bg-slate-950/60 border border-slate-800 rounded-2xl space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-400 flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-400" /> Perímetro Seguro:
              </span>
              <span className="font-semibold text-emerald-400">
                {puppy.currentGeofence}
              </span>
            </div>

            <div className="flex items-center justify-between text-xs pt-1.5 border-t border-slate-800/80">
              <span className="text-slate-400 flex items-center gap-1.5">
                <MapPin className="w-4 h-4 text-amber-400" /> Ubicación GPS:
              </span>
              <span className="font-mono-nums text-slate-300">
                {puppy.currentPosition.lat.toFixed(5)}, {puppy.currentPosition.lng.toFixed(5)}
              </span>
            </div>
          </div>

          {/* Remote Actions on Collar */}
          <div className="space-y-2">
            <h4 className="text-xs font-bold text-slate-400 tracking-wider uppercase">
              Controles Remotos del Collar
            </h4>

            <div className="grid grid-cols-2 gap-2.5">
              {/* Sound Beep Buzzer */}
              <button
                onClick={triggerBuzzer}
                className={`p-3 rounded-xl border flex items-center gap-2.5 text-xs font-bold transition-all ${
                  buzzerActive
                    ? 'bg-amber-500 text-slate-950 border-amber-400 shadow-lg scale-98'
                    : 'bg-slate-800/80 hover:bg-slate-800 text-slate-200 border-slate-700'
                }`}
              >
                <Volume2 className={`w-4 h-4 ${buzzerActive ? 'animate-bounce' : 'text-amber-400'}`} />
                <div className="text-left">
                  <div>Emitir Sonido</div>
                  <div className="text-[10px] opacity-80 font-normal">
                    {buzzerActive ? '¡Sonando...!' : 'Beep localizador'}
                  </div>
                </div>
              </button>

              {/* Collar LED Light */}
              <button
                onClick={() => setLedActive(!ledActive)}
                className={`p-3 rounded-xl border flex items-center gap-2.5 text-xs font-bold transition-all ${
                  ledActive
                    ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500 shadow-sm'
                    : 'bg-slate-800/80 hover:bg-slate-800 text-slate-200 border-slate-700'
                }`}
              >
                <Lightbulb className={`w-4 h-4 ${ledActive ? 'text-cyan-400 animate-pulse' : 'text-slate-400'}`} />
                <div className="text-left">
                  <div>Luz LED Nocturna</div>
                  <div className="text-[10px] opacity-80 font-normal">
                    {ledActive ? 'Encendida (Cyan)' : 'Apagada'}
                  </div>
                </div>
              </button>
            </div>
          </div>

          {/* Tutor info */}
          <div className="p-3 bg-slate-950/40 rounded-xl border border-slate-800 flex items-center justify-between text-xs text-slate-400">
            <div className="flex items-center gap-2">
              <Phone className="w-3.5 h-3.5 text-slate-500" />
              <span>Tutor: {puppy.assignedDriverOrOwner}</span>
            </div>
            <span className="font-mono-nums text-slate-300">55-8932-1104</span>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-slate-950/80 border-t border-slate-800 flex items-center justify-between gap-3">
          <button
            onClick={() => {
              onCenterMap();
              onClose();
            }}
            className="flex-1 py-2.5 px-4 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold rounded-xl text-xs flex items-center justify-center gap-2 transition-colors shadow-lg"
          >
            <MapPin className="w-4 h-4" />
            Centrar Mapa en Max
          </button>
          <button
            onClick={onClose}
            className="py-2.5 px-5 bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold rounded-xl text-xs transition-colors"
          >
            Cerrar
          </button>
        </div>

      </div>
    </div>
  );
};
