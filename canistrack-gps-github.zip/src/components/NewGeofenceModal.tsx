import React, { useState } from 'react';
import { X, ShieldPlus, MapPin } from 'lucide-react';
import { GeofenceZone, GPSCoordinate } from '../types/gps';

interface NewGeofenceModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddGeofence: (newZone: GeofenceZone) => void;
  defaultCenter: GPSCoordinate;
}

export const NewGeofenceModal: React.FC<NewGeofenceModalProps> = ({
  isOpen,
  onClose,
  onAddGeofence,
  defaultCenter,
}) => {
  const [name, setName] = useState('');
  const [radiusKm, setRadiusKm] = useState(2.5);
  const [color, setColor] = useState('#06b6d4');
  const [borderStyle, setBorderStyle] = useState<'solid' | 'dashed'>('dashed');
  const [alertOnExit, setAlertOnExit] = useState(true);
  const [alertOnEntry, setAlertOnEntry] = useState(true);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const newZone: GeofenceZone = {
      id: `geo-custom-${Date.now()}`,
      name: name.trim(),
      center: defaultCenter,
      radiusMeters: radiusKm * 1000,
      color,
      borderStyle,
      iconType: 'fence',
      active: true,
      alertOnExit,
      alertOnEntry,
    };

    onAddGeofence(newZone);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[600] flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div 
        className="w-full max-w-md bg-slate-900 border border-slate-700/80 rounded-3xl shadow-2xl overflow-hidden flex flex-col text-slate-100"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="p-4 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/40 flex items-center justify-center">
              <ShieldPlus className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">
                Crear Nueva Geocerca
              </h3>
              <p className="text-[11px] text-slate-400">
                Define perímetro seguro o zona de alerta
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Nombre de la Geocerca
            </label>
            <input
              type="text"
              required
              placeholder="Ej. Zona Casa, Parque Centenario, Almacén..."
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-cyan-500"
            />
          </div>

          <div>
            <div className="flex items-center justify-between text-xs font-semibold text-slate-300 mb-1.5">
              <span>Radio del Perímetro: {radiusKm} km</span>
              <span className="text-slate-400 font-mono-nums font-normal">{(radiusKm * 1000).toLocaleString()} m</span>
            </div>
            <input
              type="range"
              min="0.5"
              max="10"
              step="0.5"
              value={radiusKm}
              onChange={(e) => setRadiusKm(parseFloat(e.target.value))}
              className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-400"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Color del Marcador
            </label>
            <div className="flex items-center gap-3">
              {[
                { hex: '#06b6d4', name: 'Cyan' },
                { hex: '#f97316', name: 'Naranja' },
                { hex: '#10b981', name: 'Verde' },
                { hex: '#eab308', name: 'Amarillo' },
                { hex: '#a855f7', name: 'Púrpura' },
              ].map((c) => (
                <button
                  key={c.hex}
                  type="button"
                  onClick={() => setColor(c.hex)}
                  className={`w-7 h-7 rounded-full border-2 transition-transform ${
                    color === c.hex ? 'scale-125 border-white ring-2 ring-cyan-400/50' : 'border-slate-800 opacity-70 hover:opacity-100'
                  }`}
                  style={{ backgroundColor: c.hex }}
                />
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3 pt-1">
            <label className="flex items-center gap-2 p-2.5 rounded-xl bg-slate-950/60 border border-slate-800 cursor-pointer text-xs">
              <input
                type="checkbox"
                checked={alertOnExit}
                onChange={(e) => setAlertOnExit(e.target.checked)}
                className="rounded accent-cyan-400"
              />
              <span className="text-slate-300 font-medium">Alerta al Salir</span>
            </label>

            <label className="flex items-center gap-2 p-2.5 rounded-xl bg-slate-950/60 border border-slate-800 cursor-pointer text-xs">
              <input
                type="checkbox"
                checked={alertOnEntry}
                onChange={(e) => setAlertOnEntry(e.target.checked)}
                className="rounded accent-cyan-400"
              />
              <span className="text-slate-300 font-medium">Alerta al Entrar</span>
            </label>
          </div>

          <div className="p-3 bg-slate-950/40 rounded-xl border border-slate-800 text-[11px] text-slate-400 flex items-center gap-2">
            <MapPin className="w-3.5 h-3.5 text-amber-400 shrink-0" />
            <span>El centro se establecerá en la posición actual de la vista seleccionada.</span>
          </div>

          <div className="pt-2 flex items-center justify-end gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-300 rounded-xl transition-colors"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold rounded-xl transition-colors shadow-lg"
            >
              Guardar Geocerca
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
