// Helper to generate custom Leaflet HTML markers with high-fidelity graphics

export function createPuppyMarkerHtml(
  heading: number,
  speed: number,
  name: string,
  isSelected: boolean,
  isMoving: boolean
): string {
  // Light brown golden caramel palette for the 3D walking puppy
  // Fur primary: #d97706, Fur light: #fbbf24, Fur deep: #b45309, Muzzle: #fef3c7
  const walkSpeedSeconds = speed > 20 ? '0.3s' : speed > 10 ? '0.45s' : '0.6s';

  return `
    <div class="puppy-marker-container ${isSelected ? 'selected' : ''}" style="position: relative; width: 72px; height: 72px; display: flex; align-items: center; justify-content: center; pointer-events: auto;">
      
      <!-- Directional Navigation Radar / Heading Beam -->
      <div class="heading-cone" style="
        position: absolute;
        top: -30px;
        left: 50%;
        transform: translateX(-50%) rotate(${heading}deg);
        transform-origin: 50% 66px;
        pointer-events: none;
        z-index: 1;
        transition: transform 0.35s cubic-bezier(0.16, 1, 0.3, 1);
      ">
        <svg width="70" height="85" viewBox="0 0 70 85" fill="none" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <linearGradient id="navBeamGlow3D" x1="35" y1="0" x2="35" y2="85" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stop-color="#38bdf8" stop-opacity="0.9" />
              <stop offset="50%" stop-color="#0284c7" stop-opacity="0.35" />
              <stop offset="100%" stop-color="#0284c7" stop-opacity="0" />
            </linearGradient>
            <filter id="coneGlow3D" x="-10" y="-10" width="90" height="105" filterUnits="userSpaceOnUse">
              <feGaussianBlur stdDeviation="3.5" result="blur" />
              <feComposite in="SourceGraphic" in2="blur" operator="over" />
            </filter>
          </defs>
          
          <!-- Directional Cone Light -->
          <polygon points="35,10 6,80 64,80" fill="url(#navBeamGlow3D)" filter="url(#coneGlow3D)" />
          
          <!-- 3D Forward Navigation Arrow Pointer -->
          <path d="M35 4 L44 20 L35 15 L26 20 Z" fill="#38bdf8" stroke="#ffffff" stroke-width="1.8" stroke-linejoin="round" />
        </svg>
      </div>

      <!-- Pulsing GPS Radar Ground Disc -->
      <div style="
        position: absolute;
        width: 64px;
        height: 64px;
        border-radius: 50%;
        border: 2px solid rgba(56, 189, 248, 0.65);
        background: radial-gradient(circle, rgba(56, 189, 248, 0.25) 0%, rgba(56, 189, 248, 0.05) 70%, transparent 100%);
        box-shadow: 0 0 20px rgba(56, 189, 248, 0.45);
        animation: gpsPulse 2s infinite ease-out;
        z-index: 2;
      "></div>

      <!-- Isometric 3D Walking Puppy Character Container -->
      <div class="puppy-body-wrapper" style="
        position: relative;
        width: 56px;
        height: 56px;
        transform: rotate(${heading}deg);
        transition: transform 0.35s cubic-bezier(0.16, 1, 0.3, 1);
        z-index: 3;
        display: flex;
        align-items: center;
        justify-content: center;
      ">
        <svg width="56" height="56" viewBox="0 0 120 120" fill="none" xmlns="http://www.w3.org/2000/svg" style="filter: drop-shadow(0 6px 10px rgba(0,0,0,0.65));">
          <defs>
            <!-- 3D Gradients for Caramel Golden Fur Shading -->
            <linearGradient id="body3DGrad" x1="60" y1="20" x2="60" y2="100" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stop-color="#f59e0b" />
              <stop offset="60%" stop-color="#d97706" />
              <stop offset="100%" stop-color="#b45309" />
            </linearGradient>

            <linearGradient id="head3DGrad" x1="60" y1="25" x2="60" y2="75" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stop-color="#fbbf24" />
              <stop offset="50%" stop-color="#f59e0b" />
              <stop offset="100%" stop-color="#d97706" />
            </linearGradient>

            <radialGradient id="groundShadow" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stop-color="rgba(0,0,0,0.6)" />
              <stop offset="100%" stop-color="rgba(0,0,0,0)" />
            </radialGradient>
          </defs>

          <!-- 3D Ground Contact Shadow under Puppy -->
          <ellipse cx="60" cy="98" rx="36" ry="12" fill="url(#groundShadow)" />

          <!-- Back-Left Walking Leg -->
          <g style="${isMoving ? `animation: dogWalkGait2 ${walkSpeedSeconds} infinite ease-in-out; transform-origin: 40px 72px;` : ''}">
            <rect x="36" y="70" width="10" height="26" rx="5" fill="#b45309" stroke="#92400e" stroke-width="1.5" />
            <ellipse cx="41" cy="95" rx="7" ry="4" fill="#fef3c7" />
          </g>

          <!-- Back-Right Walking Leg -->
          <g style="${isMoving ? `animation: dogWalkGait1 ${walkSpeedSeconds} infinite ease-in-out; transform-origin: 80px 72px;` : ''}">
            <rect x="74" y="70" width="10" height="26" rx="5" fill="#b45309" stroke="#92400e" stroke-width="1.5" />
            <ellipse cx="79" cy="95" rx="7" ry="4" fill="#fef3c7" />
          </g>

          <!-- Animated Wagging Tail -->
          <g style="${isMoving ? 'animation: dogTailWag 0.28s infinite ease-in-out; transform-origin: 60px 88px;' : ''}">
            <path d="M57 88 C 55 98, 48 108, 38 114 C 48 110, 58 104, 63 88 Z" fill="#d97706" stroke="#b45309" stroke-width="1.5" />
          </g>

          <!-- 3D Puppy Body / Torso (with walking bob) -->
          <g style="${isMoving ? `animation: dogBodyBob ${walkSpeedSeconds} infinite ease-in-out;` : ''}">
            <!-- Torso volume -->
            <ellipse cx="60" cy="72" rx="26" ry="22" fill="url(#body3DGrad)" stroke="#b45309" stroke-width="2" />
            <!-- Back spine highlight -->
            <ellipse cx="60" cy="66" rx="16" ry="14" fill="#f59e0b" opacity="0.6" />

            <!-- Front-Left Walking Leg -->
            <g style="${isMoving ? `animation: dogWalkGait1 ${walkSpeedSeconds} infinite ease-in-out; transform-origin: 44px 60px;` : ''}">
              <rect x="40" y="58" width="11" height="30" rx="5.5" fill="#d97706" stroke="#b45309" stroke-width="1.5" />
              <ellipse cx="45.5" cy="86" rx="7.5" ry="4.5" fill="#fef3c7" />
            </g>

            <!-- Front-Right Walking Leg -->
            <g style="${isMoving ? `animation: dogWalkGait2 ${walkSpeedSeconds} infinite ease-in-out; transform-origin: 76px 60px;` : ''}">
              <rect x="69" y="58" width="11" height="30" rx="5.5" fill="#d97706" stroke="#b45309" stroke-width="1.5" />
              <ellipse cx="74.5" cy="86" rx="7.5" ry="4.5" fill="#fef3c7" />
            </g>

            <!-- 3D Puppy Head with Ear Flop -->
            <g>
              <!-- Left Floppy Ear -->
              <g style="${isMoving ? 'animation: dogEarFlop 0.45s infinite ease-in-out; transform-origin: 38px 38px;' : ''}">
                <path d="M38 38 C 26 44, 22 62, 32 72 C 36 74, 42 66, 40 52 Z" fill="#b45309" stroke="#92400e" stroke-width="2" />
              </g>

              <!-- Right Floppy Ear -->
              <g style="${isMoving ? 'animation: dogEarFlop 0.45s infinite ease-in-out; transform-origin: 82px 38px;' : ''}">
                <path d="M82 38 C 94 44, 98 62, 88 72 C 84 74, 78 66, 80 52 Z" fill="#b45309" stroke="#92400e" stroke-width="2" />
              </g>

              <!-- Head Base (Caramel / Tan) -->
              <ellipse cx="60" cy="46" rx="27" ry="24" fill="url(#head3DGrad)" stroke="#b45309" stroke-width="2" />
              <!-- Forehead glow -->
              <ellipse cx="60" cy="38" rx="14" ry="10" fill="#fbbf24" opacity="0.8" />

              <!-- Snout / Muzzle (Creamy tan) -->
              <ellipse cx="60" cy="53" rx="15" ry="11" fill="#fef3c7" stroke="#d97706" stroke-width="1.5" />

              <!-- Wet Black Nose with shine -->
              <path d="M55 48 C 55 45, 65 45, 65 48 C 65 52, 62 55, 60 55 C 58 55, 55 52, 55 48 Z" fill="#18181b" />
              <circle cx="58" cy="48" r="1.3" fill="#ffffff" />

              <!-- Cheerful Puppy Smile -->
              <path d="M56 55 Q 60 58 64 55" stroke="#18181b" stroke-width="1.6" stroke-linecap="round" fill="none" />
              ${isMoving ? '<path d="M58 56 Q 60 61 62 56 Z" fill="#f43f5e" />' : ''}

              <!-- Big Expressive Puppy Eyes with Depth -->
              <!-- Left Eye -->
              <circle cx="49" cy="42" r="5" fill="#18181b" />
              <circle cx="47.5" cy="40.5" r="1.8" fill="#ffffff" />
              <circle cx="50.5" cy="43.5" r="0.8" fill="#ffffff" />

              <!-- Right Eye -->
              <circle cx="71" cy="42" r="5" fill="#18181b" />
              <circle cx="69.5" cy="40.5" r="1.8" fill="#ffffff" />
              <circle cx="72.5" cy="43.5" r="0.8" fill="#ffffff" />

              <!-- High-Tech GPS Collar & Beacon -->
              <rect x="42" y="63" width="36" height="8" rx="4" fill="#0284c7" stroke="#38bdf8" stroke-width="1.5" />
              <!-- Pulsing LED on collar -->
              <circle cx="60" cy="67" r="3.2" fill="#22c55e" stroke="#ffffff" stroke-width="0.8" />
              <circle cx="60" cy="67" r="1.2" fill="#ffffff" />

              <!-- Forward Navigation Arrow at Nose -->
              <polygon points="60,18 65,26 55,26" fill="#38bdf8" stroke="#ffffff" stroke-width="1" />
            </g>
          </g>
        </svg>
      </div>

      <!-- Floating Name and Speed Tag -->
      <div style="
        position: absolute;
        bottom: -22px;
        left: 50%;
        transform: translateX(-50%);
        background: rgba(15, 23, 42, 0.95);
        border: 1px solid rgba(56, 189, 248, 0.6);
        border-radius: 9999px;
        padding: 2px 8px;
        display: flex;
        align-items: center;
        gap: 4px;
        white-space: nowrap;
        box-shadow: 0 4px 14px rgba(0,0,0,0.7);
        pointer-events: none;
        z-index: 4;
      ">
        <span style="font-size: 10px; font-weight: 800; color: #f59e0b;">🐕 ${name}</span>
        <span style="font-size: 9px; font-family: monospace; color: #38bdf8; font-weight: 700;">${speed} km/h</span>
      </div>

    </div>
  `;
}

export function createVehicleMarkerHtml(
  type: 'truck' | 'van' | 'car',
  color: string,
  speed: number,
  heading: number,
  hasAlert: boolean = false
): string {
  // Pin with vehicle icon inside, exactly matching image 1 and 2
  const iconSvg = type === 'truck'
    ? `<path d="M2 4h11v9H2V4zm11 3h4l3 3v3h-7V7zm-8 8a2 2 0 100-4 2 2 0 000 4zm11 0a2 2 0 100-4 2 2 0 000 4z" fill="#ffffff" />`
    : type === 'van'
    ? `<path d="M3 5h10v8H3V5zm10 2h3l3 2v4h-6V7zm-8 8a2 2 0 100-4 2 2 0 000 4zm10 0a2 2 0 100-4 2 2 0 000 4z" fill="#ffffff" />`
    : `<path d="M4 7h12l2 4v4H2v-4l2-4zm1 9a2 2 0 100-4 2 2 0 000 4zm10 0a2 2 0 100-4 2 2 0 000 4z" fill="#ffffff" />`;

  return `
    <div style="position: relative; width: 44px; height: 50px; display: flex; flex-direction: column; align-items: center;">
      <!-- Teardrop Pin Marker -->
      <div style="
        width: 38px;
        height: 38px;
        border-radius: 50% 50% 50% 0;
        transform: rotate(-45deg);
        background: ${hasAlert ? '#dc2626' : color};
        box-shadow: 0 4px 14px rgba(0,0,0,0.5), 0 0 10px ${hasAlert ? 'rgba(239, 68, 68, 0.6)' : color + '80'};
        border: 2px solid #ffffff;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
      ">
        <div style="transform: rotate(45deg); display: flex; align-items: center; justify-content: center;">
          ${hasAlert ? `
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#ffffff" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
              <path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"/>
              <line x1="12" y1="9" x2="12" y2="13"/>
              <line x1="12" y1="17" x2="12.01" y2="17"/>
            </svg>
          ` : `
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
              ${iconSvg}
            </svg>
          `}
        </div>
      </div>
      
      <!-- Anchor dot below pin point -->
      <div style="
        width: 6px;
        height: 6px;
        border-radius: 50%;
        background: #ffffff;
        box-shadow: 0 0 4px rgba(0,0,0,0.6);
        margin-top: -2px;
      "></div>

      ${hasAlert ? `
        <!-- High Speed Alert floating badge matching screenshot image 1 (102 km/h) -->
        <div style="
          position: absolute;
          top: -28px;
          background: #ef4444;
          color: #ffffff;
          border: 1px solid #fee2e2;
          border-radius: 6px;
          padding: 2px 6px;
          font-size: 11px;
          font-weight: 700;
          font-family: monospace;
          display: flex;
          align-items: center;
          gap: 3px;
          box-shadow: 0 4px 10px rgba(0,0,0,0.4);
          white-space: nowrap;
        ">
          <span>⚡ ${speed} km/h</span>
        </div>
      ` : ''}
    </div>
  `;
}
