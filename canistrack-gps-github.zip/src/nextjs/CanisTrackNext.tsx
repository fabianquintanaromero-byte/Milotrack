/**
 * Next.js Integration Component for CanisTrack GPS
 *
 * Compatible with Next.js 13+, 14+, 15+ (App Router & Pages Router)
 *
 * Usage in Next.js App Router (app/tracking/page.tsx):
 *
 * ```tsx
 * "use client";
 * import dynamic from 'next/dynamic';
 *
 * const CanisTrackNext = dynamic(() => import('@/components/CanisTrackNext'), {
 *   ssr: false, // Ensures Leaflet and Three.js only execute on client-side
 *   loading: () => (
 *     <div className="w-screen h-screen bg-slate-950 flex items-center justify-center text-cyan-400 font-mono">
 *       Cargando CanisTrack GPS...
 *     </div>
 *   ),
 * });
 *
 * export default function TrackingPage() {
 *   return <CanisTrackNext apiUrl={process.env.NEXT_PUBLIC_FASTIFY_API_URL} />;
 * }
 * ```
 */

import React, { useState, useEffect } from 'react';
import App from '../App';

export interface CanisTrackNextProps {
  apiUrl?: string;
  initialMode?: 'dark' | 'satellite' | 'hybrid';
  onDeviceSelect?: (deviceId: string) => void;
}

export default function CanisTrackNext({
  apiUrl,
  initialMode = 'dark',
  onDeviceSelect,
}: CanisTrackNextProps) {
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    // Inject API Base URL into client window if provided
    if (apiUrl && typeof window !== 'undefined') {
      (window as any).CANISTRACK_API_URL = apiUrl;
    }
    setMounted(true);
  }, [apiUrl]);

  if (!mounted) {
    return (
      <div className="w-screen h-screen bg-[#0b0f17] flex flex-col items-center justify-center gap-3 text-slate-300">
        <div className="w-12 h-12 rounded-2xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-2xl animate-bounce">
          🐕
        </div>
        <div className="text-xs font-mono font-semibold tracking-wider text-cyan-400">
          Iniciando Plataforma GPS (Next.js + Fastify)...
        </div>
      </div>
    );
  }

  return <App />;
}
